package com.zebra.oneapp.services.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zebra.oneapp.entities.StatusEntity;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.repositories.StatusRepository;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.services.TaskStatusService;

@Service
@Transactional
public class TaskStatusServiceImpl implements TaskStatusService {

    final Logger log = LoggerFactory.getLogger(TaskStatusServiceImpl.class);

    @Autowired
    private StatusRepository statusRepository;
    
    
    @Override
    @Cacheable("status_list")
    public ResponsePayload getStatusList() {
         try {
             List<StatusEntity> statusList = statusRepository.findAll();
             return new ResponsePayload(statusList,"list of status", ResponseEnum.SUCCESS, HttpStatus.OK);
         }catch (Exception e){
             log.error("In getStatusList method. Error while fetching status list.");
             return new ResponsePayload(e.getMessage(), ResponseEnum.FAIL,HttpStatus.INTERNAL_SERVER_ERROR);
         }
    }
}
