package com.zebra.oneapp.services;

import com.zebra.oneapp.dto.CommentDTO;
import com.zebra.oneapp.dto.TaskCommentDTO;
import com.zebra.oneapp.response.entities.ResponsePayload;

public interface TaskCommentsService {

    ResponsePayload getAllTaskComments(Long taskId);
    ResponsePayload  createTaskComments(TaskCommentDTO taskCommentDTO);

    ResponsePayload  updateTaskComments(Long commentId, CommentDTO commentDTO);

    ResponsePayload  deleteTaskComments(Long commentId);



}
