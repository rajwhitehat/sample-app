package com.zebra.oneapp.services.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.zebra.oneapp.dto.*;
import com.zebra.oneapp.entities.*;
import com.zebra.oneapp.repositories.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zebra.oneapp.configurations.Constants;
import com.zebra.oneapp.dao.TaskSpecificationBuilder;
import com.zebra.oneapp.enums.OperationEnum;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.enums.StatusEnum;
import com.zebra.oneapp.enums.TaskFilterKeyEnum;
import com.zebra.oneapp.exceptions.ApplicationLayerException;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.services.TaskService;
import com.zebra.oneapp.utils.MapperUtil;
import com.zebra.oneapp.utils.PaginationUtil;

@Service
@Transactional
public class TaskServiceImpl implements TaskService {
	private final Logger log = LoggerFactory.getLogger(TaskServiceImpl.class);

	@Autowired
	private TaskRepository taskRepository;
	@Autowired
	private MapperUtil mapperUtil;

	@Autowired
	private CommentRepository commentRepository;

	@Autowired
	private StatusRepository statusRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private TaskHistoryRepository taskHistoryRepository;

	public ResponsePayload findById(Long id) throws ApplicationLayerException {
		try {
			Optional<TaskEntity> task = taskRepository.findById(id);
			if (task.isPresent()) {
				List<TaskCommentsEntity> taskCommentsEntityList = commentRepository.findAllByTaskAndActiveIsTrueOrderByIdDesc(task.get());
				List<TaskCommentsResponseDTO> taskComments = taskCommentsEntityList.stream().map(obj->mapperUtil.mapTaskCommentsResponseDTO(obj)).toList();
				TaskDetailResponseDTO taskDetailResponseDTO = mapperUtil.mapTaskDetailResponseDTO(task.get(),taskComments);
				log.info("In findById method. Task retrieved successfully with Id : {}", id);
				return new ResponsePayload(taskDetailResponseDTO, "Task Detail of id : "+id, ResponseEnum.SUCCESS);
			}
			return new ResponsePayload("Incorrect Task Id", ResponseEnum.NOT_FOUND, HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			log.error("In findById method. Exception in fetching task details for task : {}", id, e);
			return new ResponsePayload(e.getMessage(), ResponseEnum.FAIL, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponsePayload findAllByAssignedUser(SearchCriteriaDTO searchCriteriaDto, Long userId)
			throws ApplicationLayerException {
		try {
			Optional<UserEntity> userEntity = userRepository.findById(userId);
			if (userEntity.isEmpty()) {
				log.error("In findAllByAssignedUser method. Incorrect userId : {}", userId);
				return new ResponsePayload("Incorrect userId", ResponseEnum.NOT_FOUND, HttpStatus.NOT_FOUND);
			}

			SearchCriteria userSearchCriteria = new SearchCriteria(TaskFilterKeyEnum.ASSIGNED_USER_ID, OperationEnum.EQUAL,
					Long.toString(userId), false);
			if (searchCriteriaDto.getSearchCriteria() == null) {
				List<SearchCriteria> criteriaList = new ArrayList<>();
				searchCriteriaDto.setSearchCriteria(criteriaList);
			}
			searchCriteriaDto.getSearchCriteria().add(userSearchCriteria);
			TaskSpecificationBuilder builder = new TaskSpecificationBuilder();
			searchCriteriaDto.getSearchCriteria().forEach(builder::with);
			Specification<TaskEntity> spec = builder.build();
			Pageable pageable = PageRequest.of(searchCriteriaDto.getPage() - 1, searchCriteriaDto.getPageSize(),
					Sort.Direction.fromString(searchCriteriaDto.getSortDir().getValue()), searchCriteriaDto.getSortBy().getValue());

			Page<TaskEntity> page = taskRepository.findAll(spec, pageable);
			Map<Object, Object> paginationMap = PaginationUtil.getPaginationMap(page);

			List<TaskResponseDTO> taskResponse = page.getContent().stream()
					.map(obj -> mapperUtil.mapTaskResponseDTO(obj)).toList();
			return new ResponsePayload(taskResponse, "Task List", ResponseEnum.SUCCESS, paginationMap);
		}
		catch (DateTimeParseException e) {
			log.error("In findAllByAssignedUser method. DateTimeParseException Exception thrown. ", e);
			return new ResponsePayload(Constants.INCORRECT_DATE_TIME_VALUE + e.getMessage(), ResponseEnum.FAIL, HttpStatus.BAD_REQUEST);
		}
		catch (Exception e) {
			log.error("In findAllByAssignedUser method. Exception in fetching task list for user : {}", userId, e);
			return new ResponsePayload(e.getMessage(), ResponseEnum.FAIL, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public ResponsePayload updateTaskStatus(TaskUpdateDTO payload) {
		try {
			Optional<TaskEntity> task = taskRepository.findById(payload.getTaskId());
			if (!task.isPresent()) {
				log.error("In updateTaskStatus method. Incorrect taskId : {}", payload.getTaskId());
				return new ResponsePayload("Incorrect taskId", ResponseEnum.NOT_FOUND, HttpStatus.NOT_FOUND);
			}
			StatusEntity statusEntity = statusRepository.findByStatus(payload.getStatus());
			if (statusEntity == null) {
				log.error("In updateTaskStatus method. Incorrect statusId : {}", payload.getStatus());
				return new ResponsePayload("Incorrect statusId", ResponseEnum.NOT_FOUND, HttpStatus.NOT_FOUND);
			}
			TaskEntity taskEntity = task.get();
			StatusEnum taskStatus = taskEntity.getStatus().getStatus();
			if (taskStatus.getInvalidChangeStatuses().contains(statusEntity.getStatus())) {
				String message = String.format("Task status cannot be changed from %s to %s.", taskStatus.name(), statusEntity.getStatus().name());
				log.error("{} for task :{}",message , payload.getTaskId());
				return new ResponsePayload(message, ResponseEnum.BAD_REQUEST, HttpStatus.BAD_REQUEST);
			}
			Optional<UserEntity> user = userRepository.findById(payload.getUserId());
			if (user.isEmpty()) {
				log.error("In updateTaskStatus method. Incorrect userId : {} ", payload.getUserId());
				return new ResponsePayload("Incorrect userId", ResponseEnum.NOT_FOUND, HttpStatus.NOT_FOUND);
			} 
			UserEntity userEntity = user.get();
			if (taskEntity.getAssignedUser().getId() != userEntity.getId()) {
				log.error("In updateTaskStatus method. This task is not assigned to userId : {} ", payload.getUserId());
				return new ResponsePayload("This task is not assigned to userId : " + payload.getUserId(), ResponseEnum.NOT_FOUND, HttpStatus.NOT_FOUND);
			}

			taskEntity.setStatus(statusEntity);
			taskRepository.saveAndFlush(taskEntity);
			createTaskHistory(taskEntity, statusEntity, userEntity);
			return new ResponsePayload("Updated task successfully", ResponseEnum.SUCCESS, HttpStatus.OK);
		} catch (Exception exp) {
			log.error("In updateTaskStatus method. Error While updating task : {} ", payload.getTaskId());
			return new ResponsePayload("Error While updating task.",
					ResponseEnum.FAIL, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	private void createTaskHistory(TaskEntity task, StatusEntity statusEntity, UserEntity user){
		TaskHistoryEntity taskHistory = new TaskHistoryEntity();
		taskHistory.setTask(task);
		taskHistory.setStatus(statusEntity);
		taskHistory.setAssignedUser(user);
		taskHistoryRepository.saveAndFlush(taskHistory);
		log.info("In createTaskHistory method. Task history created successfully for task : {}", task.getId());
	}
	@Override
	public void updateOverdueTaskStatus() {
		try {
			log.info("In updateOverdueTaskStatus method.");
			List<TaskEntity> tasks = taskRepository.findByDueDateAndNotCompleted(LocalDateTime.now(),
					StatusEnum.COMPLETED);

			StatusEntity status = statusRepository.findByStatus(StatusEnum.OVERDUE);

			tasks = tasks.stream()
					.map(task -> {
						task.setStatus(status);
						return task;
					}).toList();

			taskRepository.saveAll(tasks);
			log.info("Successfully updated task status to {}", StatusEnum.OVERDUE.name());
		} catch (Exception e) {
			log.error("In updateOverdueTaskStatus method. Exception in updating task status ", e);
		}
	}
}
