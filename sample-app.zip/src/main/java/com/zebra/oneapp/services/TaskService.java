package com.zebra.oneapp.services;


import com.zebra.oneapp.dto.SearchCriteriaDTO;
import com.zebra.oneapp.dto.TaskUpdateDTO;
import com.zebra.oneapp.exceptions.ApplicationLayerException;
import com.zebra.oneapp.response.entities.ResponsePayload;

public interface TaskService {

	ResponsePayload findById(Long id) throws ApplicationLayerException;
	
	ResponsePayload findAllByAssignedUser(SearchCriteriaDTO searchCriteriaDto, Long userId) throws ApplicationLayerException;

    ResponsePayload updateTaskStatus(TaskUpdateDTO payload);
    
    void updateOverdueTaskStatus();
}
