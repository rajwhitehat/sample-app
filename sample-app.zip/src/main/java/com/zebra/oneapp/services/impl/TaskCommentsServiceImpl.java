package com.zebra.oneapp.services.impl;

import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zebra.oneapp.dto.CommentDTO;
import com.zebra.oneapp.dto.TaskCommentDTO;
import com.zebra.oneapp.dto.TaskCommentsResponseDTO;
import com.zebra.oneapp.entities.TaskCommentsEntity;
import com.zebra.oneapp.entities.TaskEntity;
import com.zebra.oneapp.entities.UserEntity;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.repositories.CommentRepository;
import com.zebra.oneapp.repositories.TaskRepository;
import com.zebra.oneapp.repositories.UserRepository;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.services.TaskCommentsService;
import com.zebra.oneapp.utils.MapperUtil;

@Service
@Transactional
public class TaskCommentsServiceImpl  implements TaskCommentsService {

    @Autowired
    private CommentRepository commentRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private TaskRepository taskRepository;
    @Autowired
    private MapperUtil mapperUtil;

    final Logger log = LoggerFactory.getLogger(TaskCommentsServiceImpl.class);
    @Override
    public ResponsePayload  getAllTaskComments(Long taskId) {
        try {
            if(log.isDebugEnabled()){
                log.debug("In getAllTaskComments method. Getting task comments for taskId : {}", taskId);
            }
            Optional<TaskEntity> task = taskRepository.findById(taskId);
            if(task.isEmpty()){
                log.error("In getAllTaskComments method of TaskCommentsServiceImpl - Invalid taskId {} ", taskId);
                return new ResponsePayload("Invalid taskId" , ResponseEnum.NOT_FOUND,HttpStatus.NOT_FOUND);
            }
            List<TaskCommentsEntity> commentList = commentRepository.findAllByTaskAndActiveIsTrue(task.get());
            List<TaskCommentsResponseDTO> commentDTOList = commentList.stream().map(obj->mapperUtil.mapTaskCommentsResponseDTO(obj)).toList();
            log.info("In getAllTaskComments method. Comments retrieved successfully for task : {} ", taskId);
            return new ResponsePayload(commentDTOList,"list of comments",ResponseEnum.SUCCESS,HttpStatus.OK);
        } catch (Exception e) {
            log.error("In getAllTaskComments method. Error in getting task comments for task : {}",taskId, e);
            return new ResponsePayload(e.getMessage(), ResponseEnum.FAIL,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponsePayload  createTaskComments(TaskCommentDTO taskCommentDTO) {
        try {
            Optional<UserEntity> user = userRepository.findById(taskCommentDTO.getUserId());
            Optional<TaskEntity> task = taskRepository.findById(taskCommentDTO.getTaskId());
            TaskCommentsEntity taskCommentsEntity = new TaskCommentsEntity();
            if(user.isEmpty()){
                log.error("In createTaskComments method of TaskCommentsServiceImpl - Invalid userId : {}", taskCommentDTO.getUserId());
                return new ResponsePayload("Invalid userId",ResponseEnum.NOT_FOUND,HttpStatus.NOT_FOUND);
            }
            if(task.isEmpty()){
                log.error("In createTaskComments method of TaskCommentsServiceImpl - Invalid taskId : {}", taskCommentDTO.getTaskId());
                return new ResponsePayload("Invalid taskId",ResponseEnum.NOT_FOUND,HttpStatus.NOT_FOUND);
            }
            if(task.get().getAssignedUser().getId()!=user.get().getId()){
                log.error("In createTaskComments method of TaskCommentsServiceImpl - Don't have permission to comment on this task   : {} ", taskCommentDTO.getTaskId());
                return new ResponsePayload("You Don't have permission to comment on this task", ResponseEnum.FORBIDDEN,HttpStatus.FORBIDDEN);
            }
            taskCommentsEntity.setComment(taskCommentDTO.getComment());
            taskCommentsEntity.setTask(task.get());
            taskCommentsEntity.setUser(user.get());
            commentRepository.save(taskCommentsEntity);
            return new ResponsePayload(mapperUtil.mapTaskCommentsResponseDTO(taskCommentsEntity),"Comment added successfully", ResponseEnum.SUCCESS,HttpStatus.OK);
        } catch (Exception e) {
            log.error("In createTaskComments method. Error in creating comment for task {}", taskCommentDTO.getTaskId(), e);
            return new ResponsePayload(e.getMessage(), ResponseEnum.FAIL,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponsePayload  updateTaskComments(Long commentId, CommentDTO commentDto) {
        try {
            Optional<TaskCommentsEntity> taskCommentsEntity = commentRepository.findById(commentId);
            if(taskCommentsEntity.isEmpty()){
                log.error("In updateTaskComments method - Invalid commentId : {}", commentId);
                return new ResponsePayload("Invalid commentId",ResponseEnum.NOT_FOUND,HttpStatus.NOT_FOUND);
            }

            if(Boolean.TRUE.equals(taskCommentsEntity.get().getActive())){
                    taskCommentsEntity.get().setComment(commentDto.getComment());
                    commentRepository.save(taskCommentsEntity.get());
                    return new ResponsePayload(mapperUtil.mapTaskCommentsResponseDTO(taskCommentsEntity.get()),"Comment updated successfully",ResponseEnum.SUCCESS,HttpStatus.OK);
            }
            return new ResponsePayload("Comment does not exist or has been deleted", ResponseEnum.BAD_REQUEST,HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("In updateTaskComments method. Error while updating comment : {}", commentId, e);
            return new ResponsePayload(e.getMessage(), ResponseEnum.FAIL,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponsePayload  deleteTaskComments(Long commentId) {
        try {
            Optional<TaskCommentsEntity> taskCommentsEntity = commentRepository.findById(commentId);
            if(taskCommentsEntity.isEmpty()){
                log.error("In deleteTaskComments method - Invalid commentId : {}", commentId);
                return new ResponsePayload("Invalid commentId",ResponseEnum.NOT_FOUND,HttpStatus.NOT_FOUND);
            }
            if(Boolean.TRUE.equals(taskCommentsEntity.get().getActive())){
                taskCommentsEntity.get().setActive(Boolean.FALSE);
                commentRepository.save(taskCommentsEntity.get());
                log.info("In deleteTaskComments method - Comment deleted successfully : {}", commentId);
                return new ResponsePayload("Comment deleted successfully", ResponseEnum.SUCCESS,HttpStatus.OK);

            }
            return new ResponsePayload("Comment has already been deleted", ResponseEnum.No_Content,HttpStatus.NO_CONTENT);

        } catch (Exception e) {
            log.error("In deleteTaskComments method. Error in deleting comment : " + commentId,e);
            return new ResponsePayload(e.getMessage(), ResponseEnum.FAIL,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
