package com.zebra.oneapp.services;

import com.zebra.oneapp.response.entities.ResponsePayload;

public interface TaskStatusService {

    ResponsePayload getStatusList();


}
