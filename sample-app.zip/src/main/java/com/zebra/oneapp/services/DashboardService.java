package com.zebra.oneapp.services;

import com.zebra.oneapp.dto.SearchCriteriaDTO;
import com.zebra.oneapp.exceptions.ApplicationLayerException;
import com.zebra.oneapp.response.entities.ResponsePayload;

public interface DashboardService {
	 ResponsePayload getTasksForDashboard(Long userId,SearchCriteriaDTO searchCriteriaDto) throws ApplicationLayerException;
}
