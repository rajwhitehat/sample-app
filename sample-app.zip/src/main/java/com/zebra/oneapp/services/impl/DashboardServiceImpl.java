package com.zebra.oneapp.services.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zebra.oneapp.configurations.Constants;
import com.zebra.oneapp.dao.TaskSpecificationBuilder;
import com.zebra.oneapp.dto.DashboardResponseDTO;
import com.zebra.oneapp.dto.SearchCriteria;
import com.zebra.oneapp.dto.SearchCriteriaDTO;
import com.zebra.oneapp.dto.StatusCount;
import com.zebra.oneapp.dto.TaskResponseDTO;
import com.zebra.oneapp.entities.TaskEntity;
import com.zebra.oneapp.entities.UserEntity;
import com.zebra.oneapp.enums.OperationEnum;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.enums.StatusEnum;
import com.zebra.oneapp.enums.TaskFilterKeyEnum;
import com.zebra.oneapp.exceptions.ApplicationLayerException;
import com.zebra.oneapp.repositories.TaskRepository;
import com.zebra.oneapp.repositories.UserRepository;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.services.DashboardService;
import com.zebra.oneapp.utils.MapperUtil;

@Service
@Transactional
public class DashboardServiceImpl implements DashboardService {

	private final Logger log = LoggerFactory.getLogger(DashboardServiceImpl.class);

	
	private final TaskRepository taskRepository;
	
	private final MapperUtil mapperUtil;

	
	private final UserRepository userRepository;
	
	public DashboardServiceImpl(TaskRepository taskRepository, MapperUtil mapperUtil, UserRepository userRepository) {
		this.taskRepository=taskRepository;
		this.mapperUtil=mapperUtil;
		this.userRepository=userRepository;
	}

	@Override
	public ResponsePayload getTasksForDashboard(Long userId, SearchCriteriaDTO searchCriteriaDto)
			throws ApplicationLayerException {
		try {
			Optional<UserEntity> userEntity = userRepository.findById(userId);
			if (userEntity.isEmpty()) {
				return new ResponsePayload("user not found", ResponseEnum.NOT_FOUND, HttpStatus.NOT_FOUND);
			}
			Pageable pageable = PageRequest.of(searchCriteriaDto.getPage() - 1, searchCriteriaDto.getPageSize(),
					Sort.Direction.fromString(searchCriteriaDto.getSortDir().getValue()), searchCriteriaDto.getSortBy().getValue());
			UserEntity user = userEntity.get();
			List<StatusCount> totalCountByStatusList = taskRepository.findStatusCounts(user);
			Long totalTaskCount = totalCountByStatusList.stream().mapToLong(obj-> obj.getCount()).sum();
			Map<String, Long> totalCountByStatusMap = totalCountByStatusList.stream()
					.map(obj -> Map.entry(obj.getStatusName().name(), obj.getCount()))
					.collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			List<TaskEntity> completeList = new ArrayList<>();
			for(StatusEnum statusEnum: StatusEnum.values()) {
				Specification<TaskEntity> tempSpec = filterAndGetSpecifiaction(statusEnum.name(),
						searchCriteriaDto, user);
				if(tempSpec != null) {
					Page<TaskEntity> tempPage = taskRepository.findAll(tempSpec, pageable);
					completeList.addAll(tempPage.getContent());
				}

			}

			List<TaskResponseDTO> taskResponse = completeList.stream().map(obj -> mapperUtil.mapTaskResponseDTO(obj))
					.toList();

			List<DashboardResponseDTO> dashBoardResponse = taskResponse.stream()
					.collect(Collectors.groupingBy(TaskResponseDTO::getStatus)).entrySet().stream()
					.map(entry -> new DashboardResponseDTO(Constants.STATUS_MAP.get(entry.getKey()), entry.getValue(),
							totalCountByStatusMap.get(entry.getKey())))
					.collect(Collectors.toList());

			for(StatusEnum status: StatusEnum.values()) {
				boolean isStatusIncluded = dashBoardResponse.stream().anyMatch(obj-> Constants.STATUS_MAP.get(status.name()).equalsIgnoreCase(obj.getStatus()));
				if(!isStatusIncluded) {
					Long totalTask =  totalCountByStatusMap.get(status.name()) != null ? totalCountByStatusMap.get(status.name()):0;
					DashboardResponseDTO dashBoardResponseDto = new DashboardResponseDTO(Constants.STATUS_MAP.get(status.name()),new ArrayList<>(),totalTask);
					dashBoardResponse.add(dashBoardResponseDto);
				}
			}

			Map<Object,Object> paginationMap = new HashMap<>();
			paginationMap.put("totalElements", totalTaskCount);
			return new ResponsePayload(dashBoardResponse, "Task List for Dashboard", ResponseEnum.SUCCESS,paginationMap );
		} catch (Exception e) {
			log.error("Exception in fetching task list for dashboard: ", e);
			return new ResponsePayload(e.getMessage(), ResponseEnum.FAIL, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	private Specification<TaskEntity>  filterAndGetSpecifiaction(String statusName, SearchCriteriaDTO dto, UserEntity user) {
		boolean isWithoutFilter = dto.getSearchCriteria() == null || dto.getSearchCriteria().isEmpty();
		boolean isStatusToFilter  = !isWithoutFilter &&   dto.getSearchCriteria().stream().anyMatch(obj -> TaskFilterKeyEnum.STATUS.getValue().equalsIgnoreCase(obj.getKey().getValue()) && statusName.equalsIgnoreCase(obj.getValue()));

		List<SearchCriteria> searchCriteriaList = new ArrayList<>();
		if(isWithoutFilter) {
			SearchCriteria statusSearchCriteria = new SearchCriteria(TaskFilterKeyEnum.STATUS,OperationEnum.EQUAL,statusName,false);
			searchCriteriaList.add(statusSearchCriteria);
		}
		if(!isStatusToFilter && !isWithoutFilter) {
			return null;
		}

	

		if( dto.getSearchCriteria() != null) {
			List<SearchCriteria> filteredSearchCriteriaList =	dto.getSearchCriteria().stream().filter(obj ->   !TaskFilterKeyEnum.STATUS.getValue().equalsIgnoreCase(obj.getKey().getValue()) || ( TaskFilterKeyEnum.STATUS.getValue().equalsIgnoreCase(obj.getKey().getValue()) && statusName.equalsIgnoreCase(obj.getValue()))).toList();
			searchCriteriaList.addAll(filteredSearchCriteriaList);	
		}

		SearchCriteria userSearchCriteria = new SearchCriteria(TaskFilterKeyEnum.ASSIGNED_USER_ID,OperationEnum.EQUAL,Long.toString(user.getId()) ,false);
		searchCriteriaList.add(userSearchCriteria);	
		
		SearchCriteriaDTO tempDto = new SearchCriteriaDTO();

		tempDto.setSearchCriteria(searchCriteriaList);


		TaskSpecificationBuilder builder = new TaskSpecificationBuilder();
		tempDto.getSearchCriteria().forEach(builder::with);
		return builder.build();
	}



}