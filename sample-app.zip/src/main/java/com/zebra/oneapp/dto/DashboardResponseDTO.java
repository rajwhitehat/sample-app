package com.zebra.oneapp.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DashboardResponseDTO {

	private String status;
	private List<TaskResponseDTO> taskList;
	private Long totalTasks;
}
