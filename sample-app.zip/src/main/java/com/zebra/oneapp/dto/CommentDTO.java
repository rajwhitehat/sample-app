package com.zebra.oneapp.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CommentDTO {

    @NotBlank(message = "comment should not be null or empty")
    @Schema(  
   		    example = "Lorem ipsum dolor sit amet. Id natus eius quo consectetur delectus et rerum officia est deserunt quis 33 quos rerum. In laudantium incidunt est explicabo voluptatem ut quasi aliquam!")
    private String comment;

}
