package com.zebra.oneapp.dto;


import lombok.Data;
import java.time.LocalDateTime;

@Data
public class TaskCommentsResponseDTO{

    private long id;
    private UserResponseDTO user;
    private LocalDateTime date;
    String comment;


}
