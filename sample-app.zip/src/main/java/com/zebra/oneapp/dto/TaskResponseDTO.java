package com.zebra.oneapp.dto;

import java.time.LocalDateTime;


import lombok.Data;

@Data
public class TaskResponseDTO {
	private Long id;
	private String title;
	private String description;
	private UserResponseDTO assignedUser;
	private LocalDateTime startDate;
	private LocalDateTime dueDate;
	private Integer priority;
	private String status;
	private LocalDateTime createdAt;
	private LocalDateTime updatedAt;
	
}
