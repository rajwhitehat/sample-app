package com.zebra.oneapp.dto;

import com.zebra.oneapp.enums.OperationEnum;
import com.zebra.oneapp.enums.TaskFilterKeyEnum;
import com.zebra.oneapp.validators.ValidSearchCriteriaDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@ValidSearchCriteriaDTO(key = "key", operation = "operation", message = "please check values for operation field")
public class SearchCriteria {
	@NotNull
	@Schema(description = "field name on which filtering needs to be done", example = "STATUS", enumAsRef = true)
	private TaskFilterKeyEnum key;

	@NotNull
	@Schema(description = "comparision operation needs to be applied", example = "EQUAL", enumAsRef = true)
	private OperationEnum operation;

	@NotBlank(message = "value should not be blank")
	@Schema(description = "value of the field we need to filter for", example = "IN_PROGRESS")
	private String value;

	@NotNull(message = "orPredicate should not be null")
	@Schema(description = "logical opearator used to combine conditions", example = "false")
	private Boolean orPredicate;
}
