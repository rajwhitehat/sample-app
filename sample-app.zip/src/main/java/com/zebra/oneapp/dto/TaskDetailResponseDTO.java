package com.zebra.oneapp.dto;

import lombok.Data;
import java.util.List;

@Data
public class TaskDetailResponseDTO extends TaskResponseDTO{
    private List<TaskCommentsResponseDTO> comments;
}
