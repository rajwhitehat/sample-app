package com.zebra.oneapp.dto;

import java.util.List;

import jakarta.validation.Valid;
import lombok.Data;

@Data
public class SearchCriteriaDTO extends TaskSearchDTO {
	@Valid
	List<SearchCriteria> searchCriteria;
}
