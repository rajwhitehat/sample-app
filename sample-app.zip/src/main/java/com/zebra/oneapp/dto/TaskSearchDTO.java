package com.zebra.oneapp.dto;




import com.zebra.oneapp.enums.SortDirection;
import com.zebra.oneapp.enums.TaskSortByEnum;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskSearchDTO {

	@NotNull
	@Schema(
 		    description = "field on which sorting needs to be applied",  
 		    example = "DUE_DATE",enumAsRef = true)
	private TaskSortByEnum  sortBy;
	@NotNull
    @Schema(
 		    description = "Direction of Sort",  
 		    example = "DESC",enumAsRef = true)
	private SortDirection sortDir;
	@Positive(message = "page should greater than or equal to 1")
    @Schema(
 		    description = "page Number",  
 		    example = "1")
	private Integer page;
	@Positive(message = "pageSize should greater than or equal to 1")
    @Schema(
 		    description = "no of records per page",  
 		    example = "10")
	private Integer pageSize;
}
