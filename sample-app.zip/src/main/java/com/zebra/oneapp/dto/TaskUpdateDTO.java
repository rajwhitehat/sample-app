package com.zebra.oneapp.dto;

import com.zebra.oneapp.enums.StatusEnum;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

import static com.zebra.oneapp.configurations.Constants.*;

@Data
@AllArgsConstructor
public class TaskUpdateDTO {
	@NotNull(message = "taskId should not be null or empty")
	@Min(value=1, message = TASK_ID_VALIDATION_MESSAGE)
	private Long taskId;

	@NotNull(message = "userId should not be null or empty")
	@Min(value=1, message = USER_ID_VALIDATION_MESSAGE)
	private Long userId;

	@Schema(enumAsRef = true)
	private StatusEnum status;
}
