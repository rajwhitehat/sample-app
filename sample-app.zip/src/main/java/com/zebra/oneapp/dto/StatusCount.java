package com.zebra.oneapp.dto;

import com.zebra.oneapp.enums.StatusEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StatusCount {
private StatusEnum statusName;
private Long count;
}
