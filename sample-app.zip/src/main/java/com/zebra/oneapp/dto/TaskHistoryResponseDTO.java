package com.zebra.oneapp.dto;

import lombok.Data;

@Data
public class TaskHistoryResponseDTO {

    private long id;
    private String userName;
    private String date;
    private String status;
}
