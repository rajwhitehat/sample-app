package com.zebra.oneapp.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

import static com.zebra.oneapp.configurations.Constants.TASK_ID_VALIDATION_MESSAGE;
import static com.zebra.oneapp.configurations.Constants.USER_ID_VALIDATION_MESSAGE;

@Data
@AllArgsConstructor
public class TaskCommentDTO extends CommentDTO {

     @NotNull(message = "taskId should not be null or empty")
     @Min(value=1, message = TASK_ID_VALIDATION_MESSAGE)
     @Schema(
 		    description = "Identifier of task",  
 		    example = "1")
     Long taskId;

     @NotNull(message = "userId should not be null or empty")
     @Min(value=1, message = USER_ID_VALIDATION_MESSAGE)
     @Schema(
    		    description = "Identifier of user",  
    		    example = "1")
     Long userId;

}
