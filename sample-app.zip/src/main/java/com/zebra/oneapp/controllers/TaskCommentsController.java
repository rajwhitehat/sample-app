package com.zebra.oneapp.controllers;

import static com.zebra.oneapp.configurations.Constants.COMMENT_ID_VALIDATION_MESSAGE;
import static com.zebra.oneapp.configurations.Constants.TASK_ID_VALIDATION_MESSAGE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zebra.oneapp.dto.CommentDTO;
import com.zebra.oneapp.dto.TaskCommentDTO;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.services.TaskCommentsService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;


@RestController
@RequestMapping("api/v1/task/comments")
@Tag(name = "Comment APIs")
public class TaskCommentsController {

	
	private TaskCommentsService taskCommentsService;
	
	public TaskCommentsController(TaskCommentsService taskCommentsService) {
		this.taskCommentsService = taskCommentsService;
	}

	Logger log = LoggerFactory.getLogger(TaskCommentsController.class);

	@Operation(description = "Return a list of all comments by taskId")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Return a list of all comments by task Id", content = {
			@Content(mediaType = "application/json",schema = @Schema(implementation = ResponsePayload.class)) }),
			@ApiResponse(responseCode = "401", description = "Unauthorised Access", content = @Content),
			@ApiResponse(responseCode = "404", description = "Invalid Task Id", content = @Content),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)})
	@GetMapping("/get/{taskId}")
	public ResponseEntity<ResponsePayload> getAllTaskComments(@Min(value=1, message = TASK_ID_VALIDATION_MESSAGE) @PathVariable("taskId") Long taskId) {
		try {
			log.info("Getting all comments for task");
			ResponsePayload response = taskCommentsService.getAllTaskComments(taskId);
			return ResponseEntity.status(HttpStatus.valueOf(response.getStatusCode())).body(response);
		}catch (Exception e){
			log.error("Error while fetching comment list", e);
			return new ResponseEntity<>(new ResponsePayload("Error while fetching comments list", ResponseEnum.FAIL),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Operation(description = "Create comment for a task")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Comment created successfully", content = {
			@Content(mediaType = "application/json",schema = @Schema(implementation = ResponsePayload.class)) }),
			@ApiResponse(responseCode = "401", description = "Unauthorised Access", content = @Content),
			@ApiResponse(responseCode = "404", description = "Invalid Task Id/user Id", content = @Content),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)})
	@PostMapping("/create")
	public ResponseEntity<ResponsePayload> createTaskComments(@Valid @RequestBody TaskCommentDTO taskCommentDTO) {
		try {
			log.info("Creating task comments");
			ResponsePayload response = taskCommentsService.createTaskComments(taskCommentDTO);
			return ResponseEntity.status(HttpStatus.valueOf(response.getStatusCode())).body(response);

		}catch (Exception e){
			log.error("Error while creating comment", e);
			return new ResponseEntity<>(new ResponsePayload("Error while creating comment", ResponseEnum.FAIL),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Operation(description = "Update comment of the Task")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Comment updated successfully", content = {
			@Content(mediaType = "application/json",schema = @Schema(implementation = ResponsePayload.class)) }),
			@ApiResponse(responseCode = "401", description = "Unauthorised Access", content = @Content),
			@ApiResponse(responseCode = "400", description = "Comment does not exist or has been deleted", content = @Content),
			@ApiResponse(responseCode = "404", description = "Invalid Comment Id", content = @Content),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
	})
	@PutMapping("/update/{commentId}")
	public ResponseEntity<ResponsePayload> updateTaskComments(@Min(value=1, message = COMMENT_ID_VALIDATION_MESSAGE) @PathVariable("commentId") Long commentId, @Valid @RequestBody CommentDTO commentDTO) {
		try {
			log.info("Updating task comments");
			ResponsePayload response = taskCommentsService.updateTaskComments(commentId, commentDTO);
			return ResponseEntity.status(HttpStatus.valueOf(response.getStatusCode())).body(response);
		}catch (Exception e){
			log.error("Error while updating comment", e);
			return new ResponseEntity<>(new ResponsePayload("Error while updating comment", ResponseEnum.FAIL),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	@Operation(description = "Delete comment by id")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Comment deleted successfully", content = {
			@Content(mediaType = "application/json",schema = @Schema(implementation = ResponsePayload.class)) }),
			@ApiResponse(responseCode = "401", description = "Unauthorised Access", content = @Content),
			@ApiResponse(responseCode = "404", description = "Invalid Comment Id", content = @Content),
			@ApiResponse(responseCode = "204", description = "No Content"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
	})
	@DeleteMapping("/delete/{commentId}")
	public ResponseEntity<ResponsePayload> deleteTaskComments(@Min(value=1, message = COMMENT_ID_VALIDATION_MESSAGE) @PathVariable("commentId") Long commentId) {
		try {
			log.info("Deleting task comments");
			ResponsePayload response = taskCommentsService.deleteTaskComments(commentId);
			return ResponseEntity.status(HttpStatus.valueOf(response.getStatusCode())).body(response);
		}catch (Exception e){
			log.error("Error while deleting comment", e);
			return new ResponseEntity<>(new ResponsePayload("Error while deleting comment", ResponseEnum.FAIL),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}

