package com.zebra.oneapp.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zebra.oneapp.dto.SearchCriteriaDTO;
import com.zebra.oneapp.dto.TaskUpdateDTO;
import com.zebra.oneapp.entities.TaskEntity;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.exceptions.ApplicationLayerException;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.services.TaskService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;

import static com.zebra.oneapp.configurations.Constants.TASK_ID_VALIDATION_MESSAGE;
import static com.zebra.oneapp.configurations.Constants.USER_ID_VALIDATION_MESSAGE;

@RestController
@RequestMapping("api/v1/task")
@Tag(name = "Task  APIs")
public class TaskController {

    private Logger log = LoggerFactory.getLogger(TaskController.class);

    @Autowired
    private TaskService taskService;

    @Operation(description = "Fetch a Task by task Id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(schema = @Schema(implementation = TaskEntity.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "401", description = "Unauthorised Access", content = @Content),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Incorrect Task Id ", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)})
    @GetMapping("/{id}")
    public ResponseEntity<ResponsePayload> getTaskById(
            @PathVariable @Min(value = 1, message = TASK_ID_VALIDATION_MESSAGE) Long id) {
        try {
            log.info("Getting task by Id");
            ResponsePayload response =  taskService.findById(id);
            return ResponseEntity.status(HttpStatus.valueOf(response.getStatusCode())).body(response);
        } catch (Exception e) {
            log.error("Error while fetching task details", e);
            return new ResponseEntity<>(new ResponsePayload("Error while fetching task details", ResponseEnum.FAIL),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

	@Operation(description = "This API will return a list of all tasks assigned to user")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "This API will return a list of all tasks assigned to user", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ResponsePayload.class)) }),
			@ApiResponse(responseCode = "401", description = "Unauthorised Access", content = @Content),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
			@ApiResponse(responseCode = "404", description = "User Not Found", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)})
    @PostMapping("/list/{userId}")
    public ResponseEntity<ResponsePayload> getTaskByUserId(@Valid @RequestBody SearchCriteriaDTO payload,
            @PathVariable @Min(value = 1, message = USER_ID_VALIDATION_MESSAGE) Long userId) {
        try {
            log.info("Finding all tasks by assigned user Id");
            ResponsePayload response = taskService.findAllByAssignedUser(payload, userId);
            return ResponseEntity.status(HttpStatus.valueOf(response.getStatusCode())).body(response);

        } catch (ApplicationLayerException e) {
            log.error("Error while fetching task list", e);
            return new ResponseEntity<>(new ResponsePayload("Error while fetching task list", ResponseEnum.FAIL),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @Operation(description = "This API will update the status of a task")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Update Status of Task", content = {
            @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = ResponsePayload.class))) }),
            @ApiResponse(responseCode = "401", description = "Unauthorised Access", content = @Content),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)})
    @PostMapping("/update")
    public ResponseEntity<ResponsePayload> updateTaskStatus(@Valid @RequestBody TaskUpdateDTO payload) {
        try {
            log.info("Updating task status");
            ResponsePayload response = taskService.updateTaskStatus(payload);
            return ResponseEntity.status(HttpStatus.valueOf(response.getStatusCode())).body(response);
        } catch (Exception e) {
            log.error("Error while updating task status", e);
            return new ResponseEntity<>(new ResponsePayload("Error while updating task", ResponseEnum.FAIL),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

}
