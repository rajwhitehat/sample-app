package com.zebra.oneapp.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.services.TaskStatusService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("api/v1/status")
@Tag(name = "Status APIs")
public class StatusController {

    
    private TaskStatusService taskStatusService;
    
    public StatusController(TaskStatusService taskStatusService) {
    	this.taskStatusService = taskStatusService;
    }

    Logger log = LoggerFactory.getLogger(StatusController.class);
    @Operation(description = "Fetches the lists of all valid statuses")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Status List", content = {
            @Content(mediaType = "application/json",schema = @Schema(implementation = ResponsePayload.class)) }),
            @ApiResponse(responseCode = "401", description = "Unauthorised Access", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)})
    @GetMapping("/list")
    public ResponseEntity<ResponsePayload> getStatusList(){
        try {
            log.info("Getting status list");
            ResponsePayload response = taskStatusService.getStatusList();
            return ResponseEntity.status(HttpStatus.valueOf(response.getStatusCode())).body(response);
        }
        catch (Exception e){
            log.error("Error while fetching status list");
            return new ResponseEntity<>(new ResponsePayload("Error while fetching status list", ResponseEnum.FAIL),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

}
