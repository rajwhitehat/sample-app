package com.zebra.oneapp.controllers;

import static com.zebra.oneapp.configurations.Constants.USER_ID_VALIDATION_MESSAGE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zebra.oneapp.dto.SearchCriteriaDTO;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.exceptions.ApplicationLayerException;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.services.DashboardService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;

@RestController
@RequestMapping("api/v1/dashboard")
@Tag(name = "Dashboard APIs")
public class DashboardController {

    Logger log = LoggerFactory.getLogger(DashboardController.class);

    
    private final DashboardService dashboardService;
    
    public DashboardController(DashboardService dashboardService) {
    	 this.dashboardService = dashboardService;
    }
    
	
	@Operation(description = "This API will return a list of tasks to be displayed on Dashboard")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "This API will return a list of tasks to be displayed on Dashboard", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ResponsePayload.class)) }),
			@ApiResponse(responseCode = "401", description = "Unauthorised Access", content = @Content),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
			@ApiResponse(responseCode = "404", description = "User Not Found", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)})
    @PostMapping("/{userId}")
    public ResponseEntity<ResponsePayload> getTaskByUserId(
            @PathVariable @Min(value=1, message= USER_ID_VALIDATION_MESSAGE) Long userId, @Valid @RequestBody SearchCriteriaDTO payload) {
        try {
            log.info("Fetching task list for Dashboard");
        	ResponsePayload response = dashboardService.getTasksForDashboard(userId,payload);
        	return ResponseEntity.status(HttpStatus.valueOf(response.getStatusCode())).body(response);
   
        } catch (ApplicationLayerException e) {
            log.error("Error while fetching task list for Dashboard", e);
            return new ResponseEntity<>(new ResponsePayload("Error while fetching task list for DashBoard", ResponseEnum.FAIL),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
}
