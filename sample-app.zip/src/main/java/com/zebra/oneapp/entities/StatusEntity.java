package com.zebra.oneapp.entities;

import java.io.Serializable;

import com.zebra.oneapp.enums.StatusEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
@Entity
@Table(name = "status_master")
@Data
public class StatusEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7563628382717685982L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private StatusEnum status;
	
	@Column(name = "alias")
	private String alias;



}
