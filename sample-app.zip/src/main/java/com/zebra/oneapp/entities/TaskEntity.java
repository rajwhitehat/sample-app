package com.zebra.oneapp.entities;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "tasks")
@Data
public class TaskEntity extends UserDateAudit{

    private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;
    
    @Column(name="start_date")
    private LocalDateTime startDate;

    @Column(name="due_date")
    private LocalDateTime dueDate;
    
    @Column(name = "priority",columnDefinition = "int default 3")
    private Integer priority;
    
    @ManyToOne
    @JsonManagedReference
    private UserEntity assignedUser; 
    
    @ManyToOne
    @JsonManagedReference
    private StatusEntity status; 
    
    @OneToMany(mappedBy="task")
    @JsonManagedReference
	private List<TaskCommentsEntity> comments;
    
    
    @OneToMany(mappedBy="task")
    @JsonManagedReference
	private List<TaskHistoryEntity> taskHistories;
    
    @OneToMany(mappedBy="task")
    @JsonManagedReference
	private List<TaskAttachmentEntity> attachments;

}
