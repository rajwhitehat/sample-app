package com.zebra.oneapp.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Table(name = "users")
@Data
public class UserEntity extends UserDateAudit {
	private static final long serialVersionUID = -7975920175117351587L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@NotBlank
	@Column(name="first_name"/*,columnDefinition = "First name of the user should not be null"*/)
	
	private String firstName;
	
	@Column(name="last_name"/*,columnDefinition = "Last name of the user should not be null"*/)
	@NotBlank
	private String lastName;

	@Column(name="email",unique=true/*,columnDefinition = "email of the user should not be null"*/)
	@NotBlank
	private String email;
	
	@Column(name = "active",columnDefinition = "boolean default true")
	private Boolean active;
	
	@OneToMany(mappedBy="assignedUser")
	@JsonBackReference
	private List<TaskEntity> task;
}
