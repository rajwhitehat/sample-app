package com.zebra.oneapp.response.entities;

import java.io.Serializable;
import java.util.Map;

import org.springframework.http.HttpStatus;

import com.zebra.oneapp.enums.ResponseEnum;

import lombok.Data;
@Data 
public class ResponsePayload extends AbstractPayload implements Serializable{

	private static final long serialVersionUID = 1L;
	private Object response;
	private Map<Object,Object> paginationMap;
	private String message;
	private ResponseEnum status;
	private Integer statusCode;

	public ResponsePayload() {
		super();
		this.statusCode= HttpStatus.OK.value();
	}
	public ResponsePayload(Object object, String message, ResponseEnum status) {
		super();
		this.response = object;
		this.message = message;
		this.status = status;
		this.statusCode= HttpStatus.OK.value();
	}

	public ResponsePayload(String message, ResponseEnum status) {
		super();
		this.message = message;
		this.status = status;
		this.statusCode= HttpStatus.OK.value();
	}
	public ResponsePayload(String message, ResponseEnum status,HttpStatus httpStatus) {
		super();
		this.message = message;
		this.status = status;
		this.statusCode=httpStatus.value();
	}
	public ResponsePayload(Object object, String message, ResponseEnum status,HttpStatus httpStatus) {
		super();
		this.response = object;
		this.message = message;
		this.status = status;
		this.statusCode=httpStatus.value();
	}

	public ResponsePayload(Object object, String message, ResponseEnum status, Map<Object,Object> paginationMap) {
		super();
		this.response = object;
		this.message = message;
		this.status = status;
		this.paginationMap= paginationMap;
		this.statusCode= HttpStatus.OK.value();
	}
}
