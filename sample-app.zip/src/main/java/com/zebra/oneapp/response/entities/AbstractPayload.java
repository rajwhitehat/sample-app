package com.zebra.oneapp.response.entities;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class AbstractPayload {
	public static Gson getGson() {
		return GSON;
	}

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	
	@Override
	public String toString() {
		return GSON.toJson(this);
	}
}
