package com.zebra.oneapp.response.entities;

import org.springframework.http.HttpStatus;

import com.zebra.oneapp.enums.ResponseEnum;

public class ErrorPayload extends AbstractPayload{

	private Object errorBodyPayload;
	private String message;
	private ResponseEnum status;
	private HttpStatus statusCode;

	public ErrorPayload() {
		super();
		this.statusCode= HttpStatus.OK;
	}
	public ErrorPayload(Object object, String message, ResponseEnum status) {
		super();
		this.errorBodyPayload = object;
		this.message = message;
		this.status = status;
		this.statusCode= HttpStatus.OK;
	}

	public ErrorPayload(String message, ResponseEnum status) {
		super();
		this.message = message;
		this.status = status;
		this.statusCode= HttpStatus.OK;
	}
	public ErrorPayload(String message, ResponseEnum status, HttpStatus httpStatus) {
		super();
		this.message = message;
		this.status = status;
		this.statusCode=httpStatus;
	}
	public ErrorPayload(Object object, String message, ResponseEnum status, HttpStatus httpStatus) {
		super();
		this.errorBodyPayload = object;
		this.message = message;
		this.status = status;
		this.statusCode=httpStatus;
	}


	public Object getErrorBodyPayload() {
		return errorBodyPayload;
	}
	public void setErrorBodyPayload(Object errorBodyPayload) {
		this.errorBodyPayload = errorBodyPayload;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public ResponseEnum getStatus() {
		return status;
	}
	public void setStatus(ResponseEnum status) {
		this.status = status;
	}
	public HttpStatus getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(HttpStatus statusCode) {
		this.statusCode = statusCode;
	}
}
