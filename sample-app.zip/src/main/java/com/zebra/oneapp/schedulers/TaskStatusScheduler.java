package com.zebra.oneapp.schedulers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.zebra.oneapp.services.TaskService;

@Component
public class TaskStatusScheduler {
	@Autowired
	private TaskService taskservice;
	
	@Scheduled(cron = "@midnight")
	public void scheduleFixedRateTask() {
		taskservice.updateOverdueTaskStatus();
	}
}
