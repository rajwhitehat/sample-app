package com.zebra.oneapp.exceptions;


/**
 * The Class ApplicationLayerException.
 */
public class ApplicationLayerException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 18349323234328L;

	/**
	 * Instantiates a new application layer exception.
	 *
	 * @param strErrorMessage the str error message
	 * @param cause the cause
	 */
	public ApplicationLayerException(String strErrorMessage, Throwable cause) {
		super(strErrorMessage, cause);
	}

	/**
	 * Instantiates a new application layer exception.
	 *
	 * @param msg the msg
	 */
	public ApplicationLayerException(String msg) {
		super(msg);
	}

}
