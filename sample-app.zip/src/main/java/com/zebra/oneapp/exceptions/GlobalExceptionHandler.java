package com.zebra.oneapp.exceptions;

import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.zebra.oneapp.configurations.Constants;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.response.entities.ResponsePayload;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
	Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);
	
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
	
		return new ResponseEntity<>(new ResponsePayload(ex.getMessage() , ResponseEnum.FAIL, HttpStatus.BAD_REQUEST),
				HttpStatus.BAD_REQUEST);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {

		Optional<String> errors = ex.getBindingResult().getAllErrors().stream().map(error -> {
			String errorMessage = error.getDefaultMessage();
			return errorMessage + " ";
		}).reduce((a, b) -> a + "," + b);
		String error = errors.isPresent() ? errors.get() : "Bad Request";
		log.error(error);
		return new ResponseEntity<>(new ResponsePayload(error, ResponseEnum.FAIL, HttpStatus.BAD_REQUEST),
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({ MethodArgumentTypeMismatchException.class })
	public ResponseEntity<Object> handleMethodArgumentTypeMismatch(MethodArgumentTypeMismatchException ex,
			WebRequest request) {
		String error = "Incorrect Value for "+ ex.getName() ;
		log.error(error);
		return new ResponseEntity<>(new ResponsePayload(error, ResponseEnum.FAIL, HttpStatus.BAD_REQUEST),
				HttpStatus.BAD_REQUEST);
	}

	@Override
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		return new ResponseEntity<>(
				new ResponsePayload("Method not allowed", ResponseEnum.FAIL, HttpStatus.METHOD_NOT_ALLOWED),
				HttpStatus.BAD_REQUEST);
	}

	@Override
	protected ResponseEntity<Object> handleHandlerMethodValidationException(HandlerMethodValidationException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		List<? extends MessageSourceResolvable> k = ex.getAllErrors();
		MessageSourceResolvable m = k.get(0);
		m.getDefaultMessage();
		Optional<String> errors = ex.getAllErrors().stream().map(obj -> obj.getDefaultMessage() + " ")
				.reduce((a, b) -> a + "," + b);
		String error = errors.isPresent() ? errors.get() : "Bad Request";
		log.error(error);
		return new ResponseEntity<>(new ResponsePayload(error, ResponseEnum.FAIL, HttpStatus.BAD_REQUEST),
				HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler({ DateTimeParseException.class })
	public ResponseEntity<Object> handleDateTimeParseException(DateTimeParseException ex,
			WebRequest request) {
		String error = Constants.INCORRECT_DATE_TIME_VALUE + ex.getMessage() ;
		log.error(error);
		return new ResponseEntity<>(new ResponsePayload(error, ResponseEnum.FAIL, HttpStatus.BAD_REQUEST),
				HttpStatus.BAD_REQUEST);
	}

}
