package com.zebra.oneapp.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.zebra.oneapp.dto.SearchCriteria;
import com.zebra.oneapp.entities.TaskEntity;

public class TaskSpecificationBuilder {
	private final List<SearchCriteria> params;

	public TaskSpecificationBuilder() {
		this.params = new ArrayList<>();
	}

	public final TaskSpecificationBuilder with(SearchCriteria searchCriteria) {
		params.add(searchCriteria);
		return this;
	}

	public Specification<TaskEntity> build() {
		if (params.isEmpty()) {
			return null;
		}

		Specification<TaskEntity> result = new TaskSpecification(params.get(0));
		for (int idx = 1; idx < params.size(); idx++) {
			SearchCriteria criteria = params.get(idx);
			result = Boolean.TRUE.equals(criteria.getOrPredicate())
					? Specification.where(result).or(new TaskSpecification(criteria))
					: Specification.where(result).and(new TaskSpecification(criteria));
		}
		return result;
	}
}
