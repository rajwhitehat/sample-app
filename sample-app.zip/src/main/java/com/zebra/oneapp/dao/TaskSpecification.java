package com.zebra.oneapp.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.zebra.oneapp.configurations.Constants;
import com.zebra.oneapp.dto.SearchCriteria;
import com.zebra.oneapp.entities.StatusEntity;
import com.zebra.oneapp.entities.TaskEntity;
import com.zebra.oneapp.entities.UserEntity;
import com.zebra.oneapp.enums.OperationEnum;
import com.zebra.oneapp.enums.TaskFilterKeyEnum;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class TaskSpecification implements Specification<TaskEntity> {

	private static final long serialVersionUID = -5178851142097713796L;
	private transient SearchCriteria criteria;

	public TaskSpecification(SearchCriteria criteria) {
		super();
		this.criteria = criteria;
	}

	@Override
	public Predicate toPredicate(Root<TaskEntity> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder){
		String key = criteria.getKey().getValue().toLowerCase();
		if (Constants.TaskFilter.USER_FIELD_LIST.contains(key)) {
			//for user related Field, currently only userId is allowed for filter
			String keyToFind = "id";
            return criteriaBuilder.equal(userJoin(root).get(keyToFind), Long.parseLong(criteria.getValue()));
		} else if (Constants.TaskFilter.STATUS_FIELD_LIST.contains(key)) {
			//for status
			switch (criteria.getOperation()) {
			case EQUAL:
				String keyName = criteria.getKey().getValue();
				return criteriaBuilder.equal(criteriaBuilder.lower(statusJoin(root).get(keyName)), criteria.getValue().toLowerCase());
			case IN:
				List<String> statusList = new ArrayList<>(Arrays.asList(criteria.getValue().split(",")));
				return criteriaBuilder.in(statusJoin(root).get(criteria.getKey().getValue())).value(statusList) ;
			default:
				break;
			}


		}else if (Constants.TaskFilter.DATE_FIELD_LIST.contains(key)) {
			//for date type
			DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
			LocalDateTime valueToCompare = LocalDateTime.parse(criteria.getValue(), formatter);
			String keyName = criteria.getKey().getValue();

			switch (criteria.getOperation()) {
			case EQUAL:
				return criteriaBuilder.equal(root.<LocalDateTime>get(keyName), valueToCompare);
			case LESS_THAN:
				return criteriaBuilder.lessThan(root.<LocalDateTime>get(keyName), valueToCompare);
			case GREATER_THAN:
				return criteriaBuilder.greaterThan(root.<LocalDateTime>get(keyName), valueToCompare);
			case GREATER_THAN_EQUAL:
				return criteriaBuilder.greaterThanOrEqualTo(root.<LocalDateTime>get(keyName), valueToCompare);
			case LESS_THAN_EQUAL:
				return criteriaBuilder.lessThanOrEqualTo(root.<LocalDateTime>get(keyName), valueToCompare);
			default:
				break;
			}

		} 

		else if(Constants.TaskFilter.NUMERIC_FIELD_LIST.contains(key)) {
			//for priority
			Integer valueToCompare = Integer.parseInt(criteria.getValue());
			String keyName = criteria.getKey().getValue();
			switch (criteria.getOperation()) {
			case EQUAL:
				return criteriaBuilder.equal(root.<Integer>get(keyName), valueToCompare);
			case LESS_THAN:
				return criteriaBuilder.lessThan(root.<Integer>get(keyName), valueToCompare);
			case GREATER_THAN:
				return criteriaBuilder.greaterThan(root.<Integer>get(keyName), valueToCompare);
			case GREATER_THAN_EQUAL:
				return criteriaBuilder.greaterThanOrEqualTo(root.<Integer>get(keyName), valueToCompare);
			case LESS_THAN_EQUAL:
				return criteriaBuilder.lessThanOrEqualTo(root.<Integer>get(keyName), valueToCompare);
			case NOT_EQUAL:
				return criteriaBuilder.notEqual(root.<Integer>get(keyName), valueToCompare);
			default:
				return null;
			}
		}
		else if(Constants.TaskFilter.STRING_FIELD_LIST.contains(key))  {
			//for title and description
			String valueToCompare = criteria.getValue().toLowerCase();
			String keyName = criteria.getKey().getValue();
			switch (criteria.getOperation()) {
			case EQUAL:
				return criteriaBuilder.equal(criteriaBuilder.lower(root.<String>get(keyName)),  valueToCompare );
			case CONTAIN:
				return criteriaBuilder.like(criteriaBuilder.lower(root.<String>get(keyName)), "%" + valueToCompare  + "%");
			default:
				return null;
			}

		} 
		return null;
	}

	private Join<TaskEntity, UserEntity> userJoin(Root<TaskEntity> root) {
		return root.join("assignedUser");
	}

	private Join<TaskEntity, StatusEntity> statusJoin(Root<TaskEntity> root) {
		return root.join("status");
	}
}
