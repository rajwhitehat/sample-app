package com.zebra.oneapp.repositories;


import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.zebra.oneapp.dto.StatusCount;
import com.zebra.oneapp.entities.StatusEntity;
import com.zebra.oneapp.entities.TaskEntity;
import com.zebra.oneapp.entities.UserEntity;
import com.zebra.oneapp.enums.StatusEnum;
import com.zebra.oneapp.exceptions.ApplicationLayerException;

public interface TaskRepository extends JpaRepository<TaskEntity, Long>, JpaSpecificationExecutor<TaskEntity> {

	Page<TaskEntity> findAllByAssignedUser(UserEntity user, Pageable pageable) throws ApplicationLayerException;
	
	Page<TaskEntity> findAllByAssignedUserAndStatus(UserEntity user,StatusEntity status ,Pageable pageable) throws ApplicationLayerException;
	
	@Query(value="SELECT NEW com.zebra.oneapp.dto.StatusCount(te.status.status,COUNT(te.id)) FROM TaskEntity te where te.assignedUser = :user GROUP BY te.status")
	List<StatusCount> findStatusCounts( @Param("user") UserEntity user);


	@Query(value="Select te from TaskEntity te where te.dueDate <= :todayDate and  te.status.status <> :status")
	List<TaskEntity> findByDueDateAndNotCompleted(LocalDateTime todayDate, StatusEnum status); 
	
	
}