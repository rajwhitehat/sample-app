package com.zebra.oneapp.repositories;

import com.zebra.oneapp.entities.TaskCommentsEntity;
import com.zebra.oneapp.entities.TaskEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CommentRepository extends JpaRepository<TaskCommentsEntity,Long> {

    List<TaskCommentsEntity> findAllByTaskAndActiveIsTrue(TaskEntity task);
    List<TaskCommentsEntity> findAllByTaskAndActiveIsTrueOrderByIdDesc(TaskEntity task);
}
