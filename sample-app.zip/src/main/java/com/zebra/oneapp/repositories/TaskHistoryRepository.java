package com.zebra.oneapp.repositories;

import com.zebra.oneapp.entities.TaskHistoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskHistoryRepository extends JpaRepository<TaskHistoryEntity, Long> {
}