package com.zebra.oneapp.repositories;


import org.springframework.data.jpa.repository.JpaRepository;

import com.zebra.oneapp.entities.StatusEntity;
import com.zebra.oneapp.enums.StatusEnum;

public interface StatusRepository extends JpaRepository<StatusEntity, Long> {
	 StatusEntity findByStatus(StatusEnum status );
}