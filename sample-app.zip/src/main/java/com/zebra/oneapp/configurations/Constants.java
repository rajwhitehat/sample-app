package com.zebra.oneapp.configurations;

import java.util.List;
import java.util.Map;

import com.zebra.oneapp.enums.TaskFilterKeyEnum;

public class Constants {

	public static final Map<String, String> STATUS_MAP = Map.ofEntries(Map.entry("NOT_STARTED", "Not Started"),
			Map.entry("IN_PROGRESS", "In Progress"), Map.entry("COMPLETED", "Completed"),
			Map.entry("FORCE_CLOSED", "Force Closed"), Map.entry("OVERDUE", "Overdue"));

	public class TaskFilter {
		private TaskFilter() {
			
		}
		public static final List<String> USER_FIELDS_ALLOWED_OPERATION = List.of("eq");
		public static final List<String> USER_FIELD_LIST = List.of("assigneduserid");

		public static final List<String> STATUS_FIELD_LIST = List.of(TaskFilterKeyEnum.STATUS.getValue());
		public static final List<String> STATUS_FIELDS_ALLOWED_OPERATION = List.of("eq", "in");

		public static final List<String> DATE_FIELD_LIST = List.of("startdate", "duedate");
		public static final List<String> DATE_FIELDS_ALLOWED_OPERATION = List.of("eq", "lt", "gt", "lte", "gte");

		public static final List<String> NUMERIC_FIELD_LIST = List.of("priority");
		public static final List<String> NUMERIC_FIELDS_ALLOWED_OPERATION = List.of("ne", "eq", "lt", "gt", "lte",
				"gte");

		public static final List<String> STRING_FIELD_LIST = List.of("description", "title");
		public static final List<String> STRING_FIELDS_ALLOWED_OPERATION = List.of("eq", "cn");

	}

	public static final String ID_VALIDATION_MESSAGE = "Id must be greater than or equal to 1";
	public static final String TASK_ID_VALIDATION_MESSAGE = "Task " + ID_VALIDATION_MESSAGE;
	public static final String USER_ID_VALIDATION_MESSAGE = "User " + ID_VALIDATION_MESSAGE;
	public static final String COMMENT_ID_VALIDATION_MESSAGE = "Comment " + ID_VALIDATION_MESSAGE;
	public static final String INCORRECT_DATE_TIME_VALUE = "Incorrect date time value -"; 

}