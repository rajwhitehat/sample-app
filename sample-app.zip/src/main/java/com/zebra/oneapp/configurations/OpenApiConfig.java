package com.zebra.oneapp.configurations;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;

@OpenAPIDefinition(info = @Info(
		description= "OpenApi Documentation for Sample App",
		title="Sample App",
		version="1.0"
		),
security=@SecurityRequirement(
		name="basic_auth"
		))
@SecurityScheme(
		name="basic_auth",
		description="basic auth required",
		scheme="basic",
		type=SecuritySchemeType.HTTP)
public class OpenApiConfig {

}
