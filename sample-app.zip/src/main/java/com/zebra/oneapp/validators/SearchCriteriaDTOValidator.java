package com.zebra.oneapp.validators;

import java.util.List;

import org.springframework.beans.BeanWrapperImpl;

import com.zebra.oneapp.configurations.Constants;
import com.zebra.oneapp.enums.OperationEnum;
import com.zebra.oneapp.enums.TaskFilterKeyEnum;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class SearchCriteriaDTOValidator implements ConstraintValidator<ValidSearchCriteriaDTO, Object> {

	private String key;
	private String operation;

	@Override
	public void initialize(ValidSearchCriteriaDTO dto) {
		this.key = dto.key();
		this.operation = dto.operation();
	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		TaskFilterKeyEnum filterKey = (TaskFilterKeyEnum) new BeanWrapperImpl(value).getPropertyValue(this.key);
		if(filterKey==null || filterKey.getValue()==null ) {
			return false;
		}
		String keySelected = filterKey.getValue().toLowerCase();
		OperationEnum operationEnum = (OperationEnum) new BeanWrapperImpl(value).getPropertyValue(this.operation);
		
		if(operationEnum==null || operationEnum.getValue()==null ) {
			return false;
		}
		String operationSelected = operationEnum.getValue().toLowerCase();
		
		if (Constants.TaskFilter.USER_FIELD_LIST.contains(keySelected)) {
			setConstraintViolation(keySelected, context, Constants.TaskFilter.USER_FIELDS_ALLOWED_OPERATION);
			return Constants.TaskFilter.USER_FIELDS_ALLOWED_OPERATION.contains(operationSelected);
		} else if (Constants.TaskFilter.STATUS_FIELD_LIST.contains(keySelected)) {
			setConstraintViolation(keySelected, context, Constants.TaskFilter.STATUS_FIELDS_ALLOWED_OPERATION);
			return Constants.TaskFilter.STATUS_FIELDS_ALLOWED_OPERATION.contains(operationSelected);
		} else if (Constants.TaskFilter.NUMERIC_FIELD_LIST.contains(keySelected)) {
			setConstraintViolation(keySelected, context, Constants.TaskFilter.NUMERIC_FIELDS_ALLOWED_OPERATION);
			return Constants.TaskFilter.NUMERIC_FIELDS_ALLOWED_OPERATION.contains(operationSelected);
		}else if (Constants.TaskFilter.DATE_FIELD_LIST.contains(keySelected)) {
			setConstraintViolation(keySelected, context, Constants.TaskFilter.DATE_FIELDS_ALLOWED_OPERATION);
			return Constants.TaskFilter.DATE_FIELDS_ALLOWED_OPERATION.contains(operationSelected);
		}else if (Constants.TaskFilter.STRING_FIELD_LIST.contains(keySelected)) {
			setConstraintViolation(keySelected, context, Constants.TaskFilter.STRING_FIELDS_ALLOWED_OPERATION);
			return Constants.TaskFilter.STRING_FIELDS_ALLOWED_OPERATION.contains(operationSelected);
		} 
		
		return false;
	}

	private void setConstraintViolation(Object key ,ConstraintValidatorContext context, List<String> allowedOperations) {
		context.disableDefaultConstraintViolation();
		context.buildConstraintViolationWithTemplate(
				"permitted values for operation key in case of " + key + " are " + allowedOperations)
				.addConstraintViolation();
	}

}
