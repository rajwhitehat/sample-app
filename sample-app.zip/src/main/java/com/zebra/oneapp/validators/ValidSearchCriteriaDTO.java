package com.zebra.oneapp.validators;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;


@Constraint(validatedBy = SearchCriteriaDTOValidator.class)
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidSearchCriteriaDTO {
	
	  String key();

	  String operation();

	  String message() default "Incorrect Values for operation field";

	  Class<?>[] groups() default {};

	  Class<? extends Payload>[] payload() default {};

}
