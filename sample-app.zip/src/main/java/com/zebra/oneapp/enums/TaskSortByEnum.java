package com.zebra.oneapp.enums;

public enum TaskSortByEnum {
	  TITLE ("title"), START_DATE ("startDate"),  DUE_DATE ("dueDate"), STATUS("status"), PRIORITY("priority");

	  private final String value;

	  TaskSortByEnum(String value) {
	    this.value = value;
	  }

	  public String getValue() {
	    return this.value;
	  } 
}
