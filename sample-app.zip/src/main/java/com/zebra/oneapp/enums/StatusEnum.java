package com.zebra.oneapp.enums;

import java.util.List;

public enum StatusEnum {
	NOT_STARTED,IN_PROGRESS,COMPLETED,FORCE_CLOSED,OVERDUE;

	public List<StatusEnum> getInvalidChangeStatuses() {
		return switch (this) {
			case NOT_STARTED -> List.of(COMPLETED);
			case COMPLETED -> List.of(NOT_STARTED,IN_PROGRESS,FORCE_CLOSED,OVERDUE);
			default -> List.of(NOT_STARTED);
		};
	}
}
