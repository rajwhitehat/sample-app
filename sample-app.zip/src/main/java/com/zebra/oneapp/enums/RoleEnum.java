package com.zebra.oneapp.enums;

public enum RoleEnum {
	ADMIN,ASSOCIATE
}
