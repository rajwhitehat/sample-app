package com.zebra.oneapp.enums;

public enum ResponseEnum {
  SUCCESS ("Success"), FAIL ("Fail"),BAD_REQUEST ("Bad Request"), No_Content("No Content"), UNAUTHORIZED("Unauthorized"),
  FORBIDDEN("Forbidden"),NOT_FOUND("Not Found");

  private final String value;

  ResponseEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return this.value;
  } 
}
