package com.zebra.oneapp.enums;

public enum OperationEnum {
	 EQUAL("eq"),  NOT_EQUAL("ne"), GREATER_THAN("gt"), LESS_THAN("lt"), GREATER_THAN_EQUAL("gte"), LESS_THAN_EQUAL("lte"), CONTAIN("cn"), IN("in");
	 
	  private final String value;

	  OperationEnum(String value) {
	    this.value = value;
	  }

	  public String getValue() {
	    return this.value;
	  } 
}
