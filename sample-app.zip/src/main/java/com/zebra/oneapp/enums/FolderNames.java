package com.zebra.oneapp.enums;

public enum FolderNames {
    TASK_ATTACHMENTS
}