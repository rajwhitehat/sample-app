package com.zebra.oneapp.enums;

public enum TaskFilterKeyEnum {
	  DUE_DATE ("dueDate"),  STATUS("status"), ASSIGNED_USER_ID("assigneduserId");

	  private final String value;

	  TaskFilterKeyEnum(String value) {
	    this.value = value;
	  }

	  public String getValue() {
	    return this.value;
	  } 
}
