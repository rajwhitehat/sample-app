package com.zebra.oneapp.utils;

import java.util.HashMap;
import java.util.Map;

import org.springframework.data.domain.Page;

public class PaginationUtil {
	
	private PaginationUtil(){ }
	public static <T> Map<Object,Object> getPaginationMap(Page<T> page) {
		Map<Object,Object> paginationMap = new HashMap<>();
		paginationMap.put("totalElements",page.getTotalElements());
		paginationMap.put("totalPages",page.getTotalPages());
		paginationMap.put("last",page.isLast());
		paginationMap.put("first",page.isFirst());
		paginationMap.put("currentPage",page.getPageable().getPageNumber() + 1);
		return paginationMap;
	}

}
