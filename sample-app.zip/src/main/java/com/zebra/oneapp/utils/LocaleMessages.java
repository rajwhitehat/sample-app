package com.zebra.oneapp.utils;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

/**
 * The Class LocaleMessages.
 */
@Component
public class LocaleMessages {

	/** The message source. */
	@Autowired
	ResourceBundleMessageSource messageSource;

	/**
	 * Gets the message by id.
	 *
	 * @param messageId the message id
	 * @return the message by id
	 */
	public String getMessageById(String messageId) {
		return messageSource.getMessage(messageId,null, Locale.US);
	}
}
 