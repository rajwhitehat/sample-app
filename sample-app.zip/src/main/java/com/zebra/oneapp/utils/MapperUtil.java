package com.zebra.oneapp.utils;

import java.time.LocalDateTime;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.zebra.oneapp.dto.TaskCommentsResponseDTO;
import com.zebra.oneapp.dto.TaskDetailResponseDTO;
import com.zebra.oneapp.dto.TaskHistoryResponseDTO;
import com.zebra.oneapp.dto.TaskResponseDTO;
import com.zebra.oneapp.entities.TaskCommentsEntity;
import com.zebra.oneapp.entities.TaskEntity;
import com.zebra.oneapp.entities.TaskHistoryEntity;


@Mapper(componentModel = "spring")
public interface MapperUtil {

    @Mapping(source = "status.status", target = "status")
    TaskResponseDTO mapTaskResponseDTO(TaskEntity task);

    @Mapping(source = "task.status.status", target = "status")
    @Mapping(source = "taskComments", target = "comments")
    TaskDetailResponseDTO mapTaskDetailResponseDTO(TaskEntity task, List<TaskCommentsResponseDTO> taskComments);


    @Mapping(expression = "java(getUpdatedDate(taskHistory))", target = "date")
    @Mapping(expression="java(getUserName(taskHistory))", target = "userName")
    @Mapping(source = "taskHistory.status.status", target = "status")
    TaskHistoryResponseDTO mapTaskHistoryResponseDTO(TaskHistoryEntity taskHistory);


    @Mapping(expression = "java(getUpdatedDate(taskComments))", target = "date")
    @Mapping(source = "user", target = "user")
    TaskCommentsResponseDTO mapTaskCommentsResponseDTO(TaskCommentsEntity taskComments);

    default String getUpdatedDate(TaskHistoryEntity taskHistory) {
        if (taskHistory != null && taskHistory.getUpdatedAt() != null)
            return taskHistory.getUpdatedAt().toString();
        return null;
    }
    default LocalDateTime getUpdatedDate(TaskCommentsEntity taskComments) {
        if (taskComments != null && taskComments.getUpdatedAt() != null)
            return taskComments.getUpdatedAt();
        return null;
    }
    default String getUserName(TaskHistoryEntity taskHistory) {
        if(taskHistory != null && taskHistory.getAssignedUser() != null)
           return taskHistory.getAssignedUser().getFirstName() + " " + taskHistory.getAssignedUser().getLastName();
        return null;
    }
    default String getUserName(TaskCommentsEntity taskComments) {
        if(taskComments != null && taskComments.getUser() != null)
            return taskComments.getUser().getFirstName() + " " + taskComments.getUser().getLastName();
        return null;
    }
}
