-- liquibase formatted sql

-- changeset pallavisrivastava:1710347025963-22
UPDATE public.status_master set alias='Not Started' where id=1;
UPDATE public.status_master set alias='In progress' where id=2;
UPDATE public.status_master set alias='Completed' where id=3;
UPDATE public.status_master set alias='Force Closed' where id=4;
UPDATE public.status_master set alias='Overdue' where id=5;