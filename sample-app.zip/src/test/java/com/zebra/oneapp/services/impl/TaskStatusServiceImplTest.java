package com.zebra.oneapp.services.impl;

import com.zebra.oneapp.entities.StatusEntity;
import com.zebra.oneapp.enums.StatusEnum;
import com.zebra.oneapp.repositories.StatusRepository;
import com.zebra.oneapp.response.entities.ResponsePayload;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class TaskStatusServiceImplTest {

    @InjectMocks
    TaskStatusServiceImpl taskStatusService;

    @Mock
    StatusRepository statusRepository;

    @Test
    public void getStatusList(){

        StatusEntity status1 = new StatusEntity();
        status1.setId(1);
        status1.setStatus(StatusEnum.NOT_STARTED);

        StatusEntity status2 = new StatusEntity();
        status2.setId(2);
        status2.setStatus(StatusEnum.IN_PROGRESS);

        List<StatusEntity> statusList = new ArrayList<>();
        statusList.add(status1);
        statusList.add(status2);

        when(statusRepository.findAll()).thenReturn(statusList);
        ResponsePayload responsePayload = taskStatusService.getStatusList();

        assertNotNull(responsePayload);
        assertEquals("list of status",responsePayload.getMessage());


    }
}
