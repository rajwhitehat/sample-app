package com.zebra.oneapp.services.impl;

import com.zebra.oneapp.Util.UtilTest;
import com.zebra.oneapp.dto.CommentDTO;
import com.zebra.oneapp.dto.TaskCommentDTO;
import com.zebra.oneapp.dto.TaskCommentsResponseDTO;
import com.zebra.oneapp.entities.TaskCommentsEntity;
import com.zebra.oneapp.entities.TaskEntity;
import com.zebra.oneapp.entities.UserEntity;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.repositories.CommentRepository;
import com.zebra.oneapp.repositories.TaskRepository;
import com.zebra.oneapp.repositories.UserRepository;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.utils.MapperUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TaskCommentServiceImplTest extends UtilTest {

    @InjectMocks
    private TaskCommentsServiceImpl taskCommentsService;

    @Mock
    private CommentRepository commentRepository;

    @Mock
    private TaskRepository taskRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private MapperUtil mapperUtil;


    ArrayList<TaskCommentsEntity> expectedCommentList = new ArrayList<>();

    @BeforeEach
    void createComment() {

        TaskEntity task = new TaskEntity();
        task.setId(1L);
        UserEntity user = new UserEntity();
        user.setId(1L);

        TaskCommentsEntity taskCommentsEntity = new TaskCommentsEntity();
        taskCommentsEntity.setTask(task);
        taskCommentsEntity.setUser(user);

        TaskCommentsEntity taskCommentsEntity1 = new TaskCommentsEntity();
        taskCommentsEntity1.setTask(task);
        taskCommentsEntity1.setUser(user);

        TaskCommentsEntity taskCommentsEntity2 = new TaskCommentsEntity();
        taskCommentsEntity2.setTask(task);
        taskCommentsEntity2.setUser(user);


        expectedCommentList.add(taskCommentsEntity);
        expectedCommentList.add(taskCommentsEntity1);
        expectedCommentList.add(taskCommentsEntity2);

    }

    @Test
    void testGetAllTaskComments() {

        TaskEntity task = new TaskEntity();
        task.setId(1L);
        when(taskRepository.findById(1L)).thenReturn(Optional.of(task));
        when(commentRepository.findAllByTaskAndActiveIsTrue(task)).thenReturn(expectedCommentList);
        List<TaskCommentsResponseDTO> expectedResponseDTO = expectedCommentList.stream().map(obj -> mapperUtil.mapTaskCommentsResponseDTO(obj)).toList();
        ResponsePayload actualResponse = taskCommentsService.getAllTaskComments(task.getId());
        ResponsePayload expected = new ResponsePayload(expectedResponseDTO, "list of comments", ResponseEnum.SUCCESS);
        List<TaskCommentsResponseDTO> bodyPayload = (List<TaskCommentsResponseDTO>) actualResponse.getResponse();
        assertEquals(expected, actualResponse);
        assertEquals(3, bodyPayload.size());


    }

    @Test
    void testCreateTaskComments() {

        TaskEntity task = new TaskEntity();
        task.setId(1L);
        UserEntity user = new UserEntity();
        user.setId(1L);
        task.setAssignedUser(user);

        TaskCommentDTO taskCommentDTO = new TaskCommentDTO(1L, 1L);
        taskCommentDTO.setComment("comment");
        when(taskRepository.findById(1L)).thenReturn(Optional.of(task));
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        ResponsePayload actualResponse = taskCommentsService.createTaskComments(taskCommentDTO);
        assertNotNull(actualResponse);
        assertEquals("Comment added successfully", actualResponse.getMessage());


    }

    @Test
    void testUpdateTaskComments() {

        TaskEntity task = new TaskEntity();
        task.setId(1L);
        UserEntity user = new UserEntity();
        user.setId(1L);

        TaskCommentsEntity taskCommentsEntity = new TaskCommentsEntity();
        taskCommentsEntity.setComment("comment");
        taskCommentsEntity.setUser(user);
        taskCommentsEntity.setTask(task);


        when(commentRepository.findById(1L)).thenReturn(Optional.of(taskCommentsEntity));

        TaskCommentsEntity updatedTaskComment = new TaskCommentsEntity();
        updatedTaskComment.setComment("new comment");
        updatedTaskComment.setId(1L);
        updatedTaskComment.setUser(user);
        updatedTaskComment.setTask(task);


        when(commentRepository.save(taskCommentsEntity)).thenReturn(updatedTaskComment);


        CommentDTO commentDTO = new CommentDTO();
        commentDTO.setComment("new comment");

        ResponsePayload actualPayLoad = taskCommentsService.updateTaskComments(1L, commentDTO);
        assertNotNull(actualPayLoad);
        assertEquals("Comment updated successfully", actualPayLoad.getMessage());

    }

    @Test
    void testDeleteTaskComments() {

        TaskEntity task = new TaskEntity();
        task.setId(1L);
        UserEntity user = new UserEntity();
        user.setId(1L);
        TaskCommentsEntity taskComments = new TaskCommentsEntity();
        taskComments.setId(1L);
        taskComments.setActive(true);
        taskComments.setTask(task);
        taskComments.setUser(user);

        when(commentRepository.findById(1L)).thenReturn(Optional.of(taskComments));

        TaskCommentsEntity updatedTaskComment = new TaskCommentsEntity();
        updatedTaskComment.setActive(false);
        when(commentRepository.save(taskComments)).thenReturn(updatedTaskComment);
        ResponsePayload expected = taskCommentsService.deleteTaskComments(1L);
        assertNotNull(expected);
        assertEquals("Comment deleted successfully", expected.getMessage());


    }

}
