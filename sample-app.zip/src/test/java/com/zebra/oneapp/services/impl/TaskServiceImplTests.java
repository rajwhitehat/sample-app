package com.zebra.oneapp.services.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.zebra.oneapp.Util.UtilTest;
import com.zebra.oneapp.dao.TaskSpecificationBuilder;
import com.zebra.oneapp.dto.*;
import com.zebra.oneapp.entities.TaskCommentsEntity;
import com.zebra.oneapp.enums.TaskSortByEnum;
import com.zebra.oneapp.enums.OperationEnum;
import com.zebra.oneapp.enums.SortDirection;
import com.zebra.oneapp.enums.StatusEnum;
import com.zebra.oneapp.enums.TaskFilterKeyEnum;
import com.zebra.oneapp.repositories.*;
import com.zebra.oneapp.utils.MapperUtil;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import com.zebra.oneapp.entities.StatusEntity;
import com.zebra.oneapp.entities.TaskEntity;
import com.zebra.oneapp.entities.UserEntity;
import com.zebra.oneapp.exceptions.ApplicationLayerException;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.utils.PaginationUtil;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class TaskServiceImplTests extends UtilTest {

	@Mock
	private TaskRepository taskRepository;

	@Mock
	private StatusRepository statusRepository;

	@Mock
	private UserRepository userRepository;

	@Mock
	private CommentRepository commentRepository;

	@Mock
	private TaskHistoryRepository taskHistoryRepository;

	@InjectMocks
	private TaskServiceImpl taskService;

	private List<TaskEntity> expectedTaskList = new ArrayList<TaskEntity>();

	private List<UserEntity> expectedUserList = new ArrayList<UserEntity>();

	@Mock
	private MapperUtil mapperUtil;

	MockedStatic<PaginationUtil> pageUtil;

	@BeforeEach
	public void createTasks() {
		TaskEntity task1 = new TaskEntity();
		TaskEntity task2 = new TaskEntity();
		TaskEntity task3 = new TaskEntity();
		task1.setId(1);
		task2.setId(2);
		task3.setId(3);

		UserEntity user1 = new UserEntity();
		user1.setId(1);
		user1.setEmail("user1@gmail.com");
		UserEntity user2 = new UserEntity();
		user2.setId(2);
		user2.setEmail("user2@gmail.com");
		UserEntity user3 = new UserEntity();
		user3.setId(3);
		user3.setEmail("user3@gmail.com");

		expectedUserList.add(user1);
		expectedUserList.add(user2);
		expectedUserList.add(user3);

		task1.setAssignedUser(user1);
		task2.setAssignedUser(user2);
		task3.setAssignedUser(user1);

		task1.setStatus(getStatus().get());

		task1.setId(1);
		task2.setId(2);
		task3.setId(3);
		expectedTaskList.add(task1);
		expectedTaskList.add(task2);
		expectedTaskList.add(task3);
	}

	private Optional<StatusEntity> getStatus() {
		StatusEntity status = new StatusEntity();
		status.setId(1L);
		status.setStatus(StatusEnum.NOT_STARTED);
		return Optional.of(status);
	}
	@AfterEach
	public void resourceCleanup() {
		if (pageUtil != null) {
			pageUtil.close();
		}

	}

	void mockPaginationUtil(Page page) {
		pageUtil = Mockito.mockStatic(PaginationUtil.class);
		Map<Object, Object> pageObj = new HashMap<>();
		pageUtil.when(() -> PaginationUtil.getPaginationMap(page))
				.thenReturn(pageObj);
	}

	@Test
	void testFindAllByAssignedUserWithCorrectUserId() throws ApplicationLayerException {
		Long correctUserId = 1L;
		String correctEmail = "user1@gmail.com";
		UserEntity user1 = new UserEntity();
		user1.setId(correctUserId);
		Pageable pageable = PageRequest.of(0, 10, Sort.Direction.fromString("asc"), "title");
		Optional<UserEntity> userEntity = expectedUserList.stream().filter(obj -> obj.getId() == correctUserId)
				.findFirst();
		List<TaskEntity> expectedTasks = expectedTaskList.stream()
				.filter(obj -> correctEmail.equals(obj.getAssignedUser().getEmail())).toList();
		Page<TaskEntity> page = new PageImpl<TaskEntity>(expectedTasks);
		mockPaginationUtil(page);
		
		List<SearchCriteria> criteriaList = new ArrayList<>();
		SearchCriteria userSearchCriteria = new SearchCriteria(TaskFilterKeyEnum.ASSIGNED_USER_ID,OperationEnum.EQUAL,Long.toString(correctUserId) ,false);
		criteriaList.add(userSearchCriteria);
		SearchCriteriaDTO searchCriteriaDto = new SearchCriteriaDTO();
		searchCriteriaDto.setSortBy(TaskSortByEnum.TITLE);
		searchCriteriaDto.setSortDir(SortDirection.ASC);
		searchCriteriaDto.setPage(1);
		searchCriteriaDto.setPageSize(10);
		searchCriteriaDto.setSearchCriteria(criteriaList);
			
		when(userRepository.findById(correctUserId)).thenReturn(userEntity);
		
		searchCriteriaDto.getSearchCriteria().add(userSearchCriteria);
		Specification<TaskEntity> specTask = getSpecification(searchCriteriaDto);
	
		when(taskRepository.findAll(any(specTask.getClass()), any(pageable.getClass()))).thenReturn(page);
		ResponsePayload actualResponse = taskService.findAllByAssignedUser(searchCriteriaDto, correctUserId);
		assertNotNull(actualResponse.getResponse());
		List<TaskResponseDTO> bodyPayload = (List<TaskResponseDTO>) actualResponse.getResponse();
		assertEquals(2, bodyPayload.size());
	}

	@Test
	void testFindAllByAssignedUserWithCorrectUserIdButNoTask() throws ApplicationLayerException {
		Long inCorrectUserId = 3L;
		String correctEmail = "user3@gmail.com";
		UserEntity user1 = new UserEntity();
		user1.setId(inCorrectUserId);
		Pageable pageable = PageRequest.of(0, 10, Sort.Direction.fromString("asc"), "title");

		Optional<UserEntity> userEntity = expectedUserList.stream().filter(obj -> obj.getId() == inCorrectUserId)
				.findFirst();
		List<TaskEntity> expectedTasks = expectedTaskList.stream()
				.filter(obj -> correctEmail.equals(obj.getAssignedUser().getEmail())).toList();
		Page<TaskEntity> page = new PageImpl<TaskEntity>(expectedTasks);
		mockPaginationUtil(page);

		List<SearchCriteria> criteriaList = new ArrayList<>();
		SearchCriteria userSearchCriteria = new SearchCriteria(TaskFilterKeyEnum.ASSIGNED_USER_ID, OperationEnum.EQUAL,
				Long.toString(inCorrectUserId), false);
		criteriaList.add(userSearchCriteria);
		SearchCriteriaDTO searchCriteriaDto = new SearchCriteriaDTO();
		searchCriteriaDto.setSortBy(TaskSortByEnum.TITLE);
		searchCriteriaDto.setSortDir(SortDirection.ASC);
		searchCriteriaDto.setPage(1);
		searchCriteriaDto.setPageSize(10);
		searchCriteriaDto.setSearchCriteria(criteriaList);

		when(userRepository.findById(inCorrectUserId)).thenReturn(userEntity);

		searchCriteriaDto.getSearchCriteria().add(userSearchCriteria);
		Specification<TaskEntity> specTask = getSpecification(searchCriteriaDto);

		when(taskRepository.findAll(any(specTask.getClass()), any(pageable.getClass()))).thenReturn(page);
		ResponsePayload actualResponse = taskService.findAllByAssignedUser(searchCriteriaDto, inCorrectUserId);
		List<TaskResponseDTO> bodyPayload = (List<TaskResponseDTO>) actualResponse.getResponse();
		assertTrue(bodyPayload.isEmpty());
	}

	@Test
	void testFindAllByAssignedUserWithInCorrectUserId() throws ApplicationLayerException {
		Long inCorrectUserId = 4L;
		String correctEmail = "user4@gmail.com";
		UserEntity user1 = new UserEntity();
		user1.setId(inCorrectUserId);
		Pageable pageable = PageRequest.of(0, 10, Sort.Direction.fromString("asc"), "title");

		Optional<UserEntity> userEntity = expectedUserList.stream().filter(obj -> obj.getId() == inCorrectUserId)
				.findFirst();
		List<TaskEntity> expectedTasks = expectedTaskList.stream()
				.filter(obj -> correctEmail.equals(obj.getAssignedUser().getEmail())).toList();
		Page<TaskEntity> page = new PageImpl<TaskEntity>(expectedTasks);
		mockPaginationUtil(page);
		TaskSearchDTO tsDto = new TaskSearchDTO(TaskSortByEnum.TITLE, SortDirection.ASC, 1, 10);
		when(userRepository.findById(inCorrectUserId)).thenReturn(userEntity);
		
		
		List<SearchCriteria> criteriaList = new ArrayList<>();
		SearchCriteria userSearchCriteria = new SearchCriteria(TaskFilterKeyEnum.ASSIGNED_USER_ID,OperationEnum.EQUAL,Long.toString(inCorrectUserId) ,false);
		criteriaList.add(userSearchCriteria);
		SearchCriteriaDTO searchCriteriaDto = new SearchCriteriaDTO();
		searchCriteriaDto.setSortBy(TaskSortByEnum.TITLE);
		searchCriteriaDto.setSortDir(SortDirection.ASC);
		searchCriteriaDto.setPage(1);
		searchCriteriaDto.setPageSize(10);
		searchCriteriaDto.setSearchCriteria(criteriaList);
		searchCriteriaDto.getSearchCriteria().add(userSearchCriteria);
		ResponsePayload actualResponse = taskService.findAllByAssignedUser(searchCriteriaDto, inCorrectUserId);
		assertNull(actualResponse.getResponse());
	}

	@Test
	void testFindByIdWithCorrectId() throws ApplicationLayerException {
		Long correctTaskId = 1L;
		Long correctUserId = 1L;
		Optional<TaskEntity> expectedTask = expectedTaskList.stream().filter(obj -> obj.getId() == correctTaskId)
				.findFirst();
		Optional<UserEntity> expectedUser = expectedUserList.stream().filter(obj -> obj.getId() == correctUserId)
				.findFirst();
		TaskCommentsEntity taskComments = new TaskCommentsEntity();
		taskComments.setId(1L);
		taskComments.setTask(expectedTask.get());
		taskComments.setComment("This is 1st Comment");
		taskComments.setUser(expectedUser.get());
		taskComments.setActive(true);
		List<TaskCommentsEntity> taskCommentsEntityList = new ArrayList<>();
		taskCommentsEntityList.add(taskComments);
		when(taskRepository.findById(correctTaskId)).thenReturn(expectedTask);
		when(commentRepository.findAllByTaskAndActiveIsTrueOrderByIdDesc(expectedTask.get())).thenReturn(taskCommentsEntityList);
		List<TaskCommentsResponseDTO> expectedResponseDTO = taskCommentsEntityList.stream().map(obj -> mapperUtil.mapTaskCommentsResponseDTO(obj)).toList();
		when(mapperUtil.mapTaskDetailResponseDTO(expectedTask.get(), expectedResponseDTO)).thenReturn(getTaskResponseDTO());


		ResponsePayload actualResponse = taskService.findById(correctTaskId);
		assertThat(actualResponse.getResponse()).isNotNull();
	}

	@Test
	void testFindByIdWithIncorrectId() throws ApplicationLayerException {
		Long incorrectTaskId = 5L;
		Optional<TaskEntity> expectedTask = expectedTaskList.stream().filter(obj -> obj.getId() == incorrectTaskId)
				.findFirst();
		when(taskRepository.findById(incorrectTaskId)).thenReturn(expectedTask);
		ResponsePayload actualResponse = taskService.findById(incorrectTaskId);
		assertThat(actualResponse.getResponse()).isNull();
	}

	@Test
	public void updateTaskStatusTest() {
		Long correctTaskId = 1L;
		Long correctUserId = 1L;
		Optional<TaskEntity> expectedTask = expectedTaskList.stream().filter(obj -> obj.getId() == correctTaskId)
				.findFirst();
		Optional<UserEntity> expectedUser = expectedUserList.stream().filter(obj -> obj.getId() == correctUserId)
				.findFirst();
		StatusEntity expectedStatus = getStatus().get();
		expectedStatus.setStatus(StatusEnum.IN_PROGRESS);
		when(taskRepository.findById(correctTaskId)).thenReturn(expectedTask);
		when(statusRepository.findByStatus(StatusEnum.IN_PROGRESS)).thenReturn(expectedStatus);
		when(userRepository.findById(1L)).thenReturn(expectedUser);
		TaskUpdateDTO updateDto = new TaskUpdateDTO(1L, 1L, StatusEnum.IN_PROGRESS);
		ResponsePayload actualResponse = taskService.updateTaskStatus(updateDto);
		assertNotNull(actualResponse.getMessage());
		assertEquals("Updated task successfully", actualResponse.getMessage());
	}


	private Specification<TaskEntity> getSpecification(SearchCriteriaDTO searchCriteriaDto) {
		TaskSpecificationBuilder builder = new TaskSpecificationBuilder();
		searchCriteriaDto.getSearchCriteria().forEach((obj) -> {
			builder.with(obj);
		});

		Specification<TaskEntity> spec = builder.build();
		return spec;
	}
}
