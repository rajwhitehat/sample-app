package com.zebra.oneapp.services.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import com.zebra.oneapp.dao.TaskSpecificationBuilder;
import com.zebra.oneapp.dto.DashboardResponseDTO;
import com.zebra.oneapp.dto.SearchCriteria;
import com.zebra.oneapp.dto.SearchCriteriaDTO;
import com.zebra.oneapp.dto.StatusCount;
import com.zebra.oneapp.dto.TaskResponseDTO;
import com.zebra.oneapp.dto.UserResponseDTO;
import com.zebra.oneapp.entities.StatusEntity;
import com.zebra.oneapp.entities.TaskEntity;
import com.zebra.oneapp.entities.UserEntity;
import com.zebra.oneapp.enums.TaskSortByEnum;
import com.zebra.oneapp.enums.OperationEnum;
import com.zebra.oneapp.enums.SortDirection;
import com.zebra.oneapp.enums.StatusEnum;
import com.zebra.oneapp.enums.TaskFilterKeyEnum;
import com.zebra.oneapp.exceptions.ApplicationLayerException;
import com.zebra.oneapp.repositories.TaskRepository;
import com.zebra.oneapp.repositories.UserRepository;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.utils.MapperUtil;
import com.zebra.oneapp.utils.PaginationUtil;

@ExtendWith(MockitoExtension.class)
class DashboardServiceImplTests {
	@Mock
	private TaskRepository taskRepository;

	@Mock
	private UserRepository userRepository;


	@InjectMocks
	private DashboardServiceImpl dashboardService;

	private List<TaskEntity> expectedTaskList = new ArrayList<TaskEntity>();

	private List<UserEntity> expectedUserList = new ArrayList<UserEntity>();

	@Mock
	private MapperUtil mapperUtil;

	MockedStatic<PaginationUtil> pageUtil;

	@BeforeEach
	public void createTasks() {
		
		StatusEntity notStarted = new StatusEntity();
		notStarted.setId(1L);
		notStarted.setStatus(StatusEnum.NOT_STARTED);
		
		StatusEntity inProgress = new StatusEntity();
		inProgress.setId(2L);
		inProgress.setStatus(StatusEnum.IN_PROGRESS);
		
		StatusEntity completed = new StatusEntity();
		completed.setId(3L);
		completed.setStatus(StatusEnum.COMPLETED);
		
		StatusEntity forceClosed = new StatusEntity();
		forceClosed.setId(4L);
		forceClosed.setStatus(StatusEnum.FORCE_CLOSED);
		
		TaskEntity task1 = new TaskEntity();
		TaskEntity task2 = new TaskEntity();
		TaskEntity task3 = new TaskEntity();
		
		task1.setId(1);
		task1.setStatus(notStarted);
		task2.setId(2);
		task2.setStatus(inProgress);
		task3.setId(3);
		task3.setStatus(completed);

		UserEntity user1 = new UserEntity();
		user1.setId(1);
		user1.setEmail("user1@gmail.com");
		UserEntity user2 = new UserEntity();
		user2.setId(2);
		user2.setEmail("user2@gmail.com");
		UserEntity user3 = new UserEntity();
		user3.setId(3);
		user3.setEmail("user3@gmail.com");

		expectedUserList.add(user1);
		expectedUserList.add(user2);
		expectedUserList.add(user3);

		task1.setAssignedUser(user1);
		task2.setAssignedUser(user2);
		task3.setAssignedUser(user1);

		task1.setId(1);
		task2.setId(2);
		task3.setId(3);
		expectedTaskList.add(task1);
		expectedTaskList.add(task2);
		expectedTaskList.add(task3);
	}
	
	void mockPaginationUtil(Page page) {
		pageUtil = Mockito.mockStatic(PaginationUtil.class);
		Map<Object, Object> pageObj = new HashMap<>();
		pageUtil.when(() -> PaginationUtil.getPaginationMap(page))
				.thenReturn(pageObj);
	}
	
	@AfterEach
	public void resourceCleanup() {
		if (pageUtil != null) {
			pageUtil.close();
		}

	}
	
	@Test
	void getTasksForDashboard() throws ApplicationLayerException {
		Long correctUserId = 1L;
		String correctEmail = "user1@gmail.com";
		UserEntity user1 = new UserEntity();
		user1.setId(correctUserId);
		Pageable pageable = PageRequest.of(0, 10, Sort.Direction.fromString("asc"), "title");
		Optional<UserEntity> userEntity = expectedUserList.stream().filter(obj -> obj.getId() == correctUserId)
				.findFirst();
		List<TaskEntity> expectedTasks = expectedTaskList.stream()
				.filter(obj -> correctEmail.equals(obj.getAssignedUser().getEmail())).toList();
		Page<TaskEntity> page = new PageImpl<TaskEntity>(expectedTasks);
		mockPaginationUtil(page);
		
		
		List<SearchCriteria> criteriaList = new ArrayList<>();
		SearchCriteria userSearchCriteria = new SearchCriteria(TaskFilterKeyEnum.ASSIGNED_USER_ID,OperationEnum.EQUAL,Long.toString(correctUserId) ,false);
		SearchCriteria notStartedSreachCriteria = new SearchCriteria(TaskFilterKeyEnum.STATUS,OperationEnum.EQUAL,StatusEnum.NOT_STARTED.name() ,false);
		SearchCriteria completedSearchCriteria = new SearchCriteria(TaskFilterKeyEnum.STATUS,OperationEnum.EQUAL,StatusEnum.COMPLETED.name() ,false);
		criteriaList.add(userSearchCriteria);
		SearchCriteriaDTO searchCriteriaDto = new SearchCriteriaDTO();
		searchCriteriaDto.setSortBy(TaskSortByEnum.TITLE);
		searchCriteriaDto.setSortDir(SortDirection.ASC);
		searchCriteriaDto.setPage(1);
		searchCriteriaDto.setPageSize(10);
		searchCriteriaDto.setSearchCriteria(criteriaList);
			
		when(userRepository.findById(correctUserId)).thenReturn(userEntity);
		
		searchCriteriaDto.getSearchCriteria().add(userSearchCriteria);
		searchCriteriaDto.getSearchCriteria().add(notStartedSreachCriteria);
		searchCriteriaDto.getSearchCriteria().add(completedSearchCriteria);
		
		Specification<TaskEntity> specTask = getSpecification(searchCriteriaDto);
		
		List<StatusCount> statusCountList = new ArrayList<>();
		for(StatusEnum status: StatusEnum.values()) {
			StatusCount statusInprogess = new StatusCount();
			statusInprogess.setStatusName(status);
			statusInprogess.setCount(1L);
		}
		
		UserResponseDTO userResDto = new UserResponseDTO();
		userResDto.setId(correctUserId);
		userResDto.setEmail(correctEmail);
		TaskResponseDTO tResDto = getTaskResponseDto(userResDto,"NOT_STARTED");
		
		when(taskRepository.findStatusCounts(any(user1.getClass()))).thenReturn(statusCountList);
		when(taskRepository.findAll(any(specTask.getClass()), any(pageable.getClass()))).thenReturn(page);
		when(mapperUtil.mapTaskResponseDTO(any(TaskEntity.class))).thenReturn(tResDto);
		ResponsePayload actualResponse = dashboardService.getTasksForDashboard(correctUserId, searchCriteriaDto);
		assertNotNull(actualResponse.getResponse());
		List<DashboardResponseDTO> bodyPayload = (List<DashboardResponseDTO>) actualResponse.getResponse();
		DashboardResponseDTO res = bodyPayload.stream().filter(obj-> obj.getStatus().equalsIgnoreCase("Not Started")).findAny().get();
		assertNotNull(res);
	}
	
	
	private Specification<TaskEntity> getSpecification(SearchCriteriaDTO searchCriteriaDto) {
		TaskSpecificationBuilder builder = new TaskSpecificationBuilder();
		searchCriteriaDto.getSearchCriteria().forEach((obj) -> {
			builder.with(obj);
		});

		Specification<TaskEntity> spec = builder.build();
		return spec;
	}
	
	private TaskResponseDTO getTaskResponseDto(UserResponseDTO user,String status) {
		TaskResponseDTO rDto = new TaskResponseDTO();
		rDto.setAssignedUser(user);
		rDto.setStatus(status);
		
		return rDto;
	}
	
}
