package com.zebra.oneapp.component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zebra.oneapp.Util.UtilTest;
import com.zebra.oneapp.controllers.TaskController;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.enums.SortDirection;
import com.zebra.oneapp.enums.TaskSortByEnum;
import com.zebra.oneapp.enums.StatusEnum;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.services.impl.TaskServiceImpl;
import com.zebra.oneapp.dto.SearchCriteriaDTO;
import com.zebra.oneapp.dto.TaskResponseDTO;
import com.zebra.oneapp.dto.TaskUpdateDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(TaskController.class)
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc(addFilters = false)
@MockBean(JpaMetamodelMappingContext.class)
public class TaskControllerTest extends UtilTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    TaskServiceImpl taskService;




    @Test
    void getTaskByIdTest() throws Exception {
        ResponsePayload response = new ResponsePayload(getTaskResponseDTO(),"Task Detail of id : "+1L, ResponseEnum.SUCCESS, HttpStatus.OK);
        given(taskService.findById(1L)).willReturn(response);

        mockMvc.perform(get("/api/v1/task/1"))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Task Detail of id : 1"))
                .andExpect(jsonPath("$.response.id").value(1))
                .andExpect(jsonPath("$.response.description").value("This is for test"))
                .andExpect(jsonPath("$.response.priority").value(1))
                .andExpect(jsonPath("$.response.status").value("Assigned"))

                .andExpect(jsonPath("$.response.assignedUser.id").value(1))
                .andExpect(jsonPath("$.response.assignedUser.firstName").value("Shruti"))
                .andExpect(jsonPath("$.response.assignedUser.lastName").value("Sharma"))
                .andExpect(jsonPath("$.response.assignedUser.email").value("s@gmail.com"))

                .andExpect(jsonPath("$.response.comments[0].id").value(1))
                .andExpect(jsonPath("$.response.comments[0].comment").value("This is 1st Comment"))
                .andExpect(jsonPath("$.response.comments[0].user.id").value(1))
                .andExpect(jsonPath("$.response.comments[0].user.firstName").value("Shruti"))
                .andExpect(jsonPath("$.response.comments[0].user.lastName").value("Sharma"))
                .andExpect(jsonPath("$.response.comments[0].user.email").value("s@gmail.com"))
                ;

    }

    @Test
    void getTaskByIdTest_NotFoundError() throws Exception {

        ResponsePayload response = new ResponsePayload("Incorrect Task Id", ResponseEnum.NOT_FOUND, HttpStatus.NOT_FOUND);
        given(taskService.findById(2L)).willReturn(response);

        mockMvc.perform(get("/api/v1/task/2"))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Incorrect Task Id"));
    }

    @Test
    void getTaskByIdTest_BadRequestError() throws Exception {

        ResponsePayload response = new ResponsePayload("Task Id must be greater than or equal to 1", ResponseEnum.FAIL, HttpStatus.BAD_REQUEST);
        given(taskService.findById(0L)).willReturn(response);

        mockMvc.perform(get("/api/v1/task/0"))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Task Id must be greater than or equal to 1 "));
    }


    @Test
    void updateTaskStatusTest() throws Exception {

        TaskUpdateDTO taskUpdateDTO = new TaskUpdateDTO(1L,1L,StatusEnum.NOT_STARTED);

        ResponsePayload response = new ResponsePayload("Updated task successfully", ResponseEnum.SUCCESS, HttpStatus.OK);
        given(taskService.updateTaskStatus(taskUpdateDTO)).willReturn(response);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/task/update")
                        .content(asJsonString(taskUpdateDTO))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
        
        @Test
        void getTasksForDashboardTest() throws Exception {

     

       	List<TaskResponseDTO> taskList = new ArrayList();
       	TaskResponseDTO task1 = new TaskResponseDTO();
       	task1.setStatus("IN_PROGRESS");
       	task1.setTitle("task 1");
       	
       	TaskResponseDTO task2 = new TaskResponseDTO();
       	task2.setStatus("COMPLETED");
       	task2.setTitle("task 2");
       	
       	TaskResponseDTO task3 = new TaskResponseDTO();
       	task3.setStatus("NOT_STARTED");
       	task3.setTitle("task 3");
       	
       	taskList.add(task1);
       	taskList.add(task2);
       	taskList.add(task3);
           

           SearchCriteriaDTO searchCriteriaDto = new SearchCriteriaDTO();
           searchCriteriaDto.setPage(1);
           searchCriteriaDto.setPageSize(3);
           searchCriteriaDto.setSortBy(TaskSortByEnum.DUE_DATE);
           searchCriteriaDto.setSortDir(SortDirection.ASC);

           ResponsePayload response = new ResponsePayload(taskList,"list of tasks", ResponseEnum.SUCCESS, HttpStatus.OK);
           given(taskService.findAllByAssignedUser(searchCriteriaDto,1L)).willReturn(response);

           mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/task/list/1").content(asJsonString(searchCriteriaDto)).contentType(MediaType.APPLICATION_JSON)
         	      .accept(MediaType.APPLICATION_JSON))
                   .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                   .andExpect(status().isOk())
                   .andExpect(jsonPath("$.message").value("list of tasks"))
                   .andExpect(jsonPath("$.response[0].status").value("IN_PROGRESS"))
                   .andExpect(jsonPath("$.response[0].title").value("task 1"))
                   .andExpect(jsonPath("$.response[1].status").value("COMPLETED"))
                   .andExpect(jsonPath("$.response[1].title").value("task 2"));


       }
        
    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
