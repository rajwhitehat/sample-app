package com.zebra.oneapp.component;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zebra.oneapp.controllers.DashboardController;
import com.zebra.oneapp.dto.DashboardResponseDTO;
import com.zebra.oneapp.dto.SearchCriteriaDTO;
import com.zebra.oneapp.dto.TaskResponseDTO;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.enums.SortDirection;
import com.zebra.oneapp.enums.TaskSortByEnum;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.services.impl.DashboardServiceImpl;


@WebMvcTest(DashboardController.class)
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc(addFilters = false)
@MockBean(JpaMetamodelMappingContext.class)
public class DashboardControllerTest {

	@Autowired
    MockMvc mockMvc;

    @MockBean
    DashboardServiceImpl dashboardService;

    @Test
     void getTasksForDashboardTest() throws Exception {

    	List<DashboardResponseDTO> dashboardResponseList = new ArrayList<>();

    	List<TaskResponseDTO> inProgressTaskList = new ArrayList<TaskResponseDTO>();
    	TaskResponseDTO inProgressTask1 = new TaskResponseDTO();
    	inProgressTask1.setStatus("IN_PROGRESS");
    	inProgressTask1.setTitle("In progress task 1");
    	
    	TaskResponseDTO inProgressTask2 = new TaskResponseDTO();
    	inProgressTask2.setStatus("IN_PROGRESS");
    	inProgressTask2.setTitle("In progress task 2");
    	
    	TaskResponseDTO inProgressTask3 = new TaskResponseDTO();
    	inProgressTask3.setStatus("IN_PROGRESS");
    	inProgressTask3.setTitle("In progress task 3");
    	
    	inProgressTaskList.add(inProgressTask1);
    	inProgressTaskList.add(inProgressTask2);
    	inProgressTaskList.add(inProgressTask3);
        
    	DashboardResponseDTO inProgressDashboardResponse = new DashboardResponseDTO();
    	inProgressDashboardResponse.setTaskList(inProgressTaskList);
    	inProgressDashboardResponse.setStatus("In Progress");
    	inProgressDashboardResponse.setTotalTasks(3L);
    	
    	dashboardResponseList.add(inProgressDashboardResponse);
    	
        SearchCriteriaDTO searchCriteriaDto = new SearchCriteriaDTO();
        searchCriteriaDto.setPage(1);
        searchCriteriaDto.setPageSize(3);
        searchCriteriaDto.setSortBy(TaskSortByEnum.DUE_DATE);
        searchCriteriaDto.setSortDir(SortDirection.ASC);

        ResponsePayload response = new ResponsePayload(dashboardResponseList,"list of tasks", ResponseEnum.SUCCESS, HttpStatus.OK);
        given(dashboardService.getTasksForDashboard(1L,searchCriteriaDto)).willReturn(response);

        mockMvc.perform(post("/api/v1/dashboard/1").content(asJsonString(searchCriteriaDto)).contentType(MediaType.APPLICATION_JSON)
      	      .accept(MediaType.APPLICATION_JSON))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("list of tasks"))
                .andExpect(jsonPath("$.response[0].status").value("In Progress"))
                .andExpect(jsonPath("$.response[0].totalTasks").value(3));


    }
    
    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
