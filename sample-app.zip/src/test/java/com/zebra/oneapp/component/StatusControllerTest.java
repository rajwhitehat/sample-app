package com.zebra.oneapp.component;

import com.zebra.oneapp.controllers.StatusController;
import com.zebra.oneapp.entities.StatusEntity;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.enums.StatusEnum;
import com.zebra.oneapp.response.entities.ResponsePayload;
import com.zebra.oneapp.services.impl.TaskStatusServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.ArrayList;
import java.util.List;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(StatusController.class)
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc(addFilters = false)
@MockBean(JpaMetamodelMappingContext.class)
class StatusControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    TaskStatusServiceImpl taskStatusService;

    @Test
     void getStatusListTest() throws Exception {

        List<StatusEntity> list = new ArrayList<>();
        StatusEntity status1 = new StatusEntity();
        status1.setId(1);
        status1.setStatus(StatusEnum.NOT_STARTED);

        StatusEntity status2 = new StatusEntity();
        status2.setId(2);
        status2.setStatus(StatusEnum.IN_PROGRESS);

        list.add(status1);
        list.add(status2);

        ResponsePayload response = new ResponsePayload(list,"list of status", ResponseEnum.SUCCESS, HttpStatus.OK);
        given(taskStatusService.getStatusList()).willReturn(response);

        mockMvc.perform(get("/api/v1/status/list"))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("list of status"))
                .andExpect(jsonPath("$.response[0].id").value(1))
                .andExpect(jsonPath("$.response[0].status").value("NOT_STARTED"))
                .andExpect(jsonPath("$.response[1].id").value(2))
                .andExpect(jsonPath("$.response[1].status").value("IN_PROGRESS"));


    }

}
