package com.zebra.oneapp.component;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.zebra.oneapp.dto.CommentDTO;
import com.zebra.oneapp.dto.TaskCommentDTO;
import com.zebra.oneapp.enums.ResponseEnum;
import com.zebra.oneapp.response.entities.ResponsePayload;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.zebra.oneapp.Util.UtilTest;
import com.zebra.oneapp.controllers.TaskCommentsController;
import com.zebra.oneapp.services.impl.TaskCommentsServiceImpl;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(TaskCommentsController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
@MockBean(JpaMetamodelMappingContext.class)
class TaskCommentControllerTest extends UtilTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    TaskCommentsServiceImpl taskCommentsService;

    @Autowired
    ObjectMapper objectMapper;
    @Test
    void getAllTaskCommentsTest() throws Exception  {



        ResponsePayload response = new ResponsePayload(getTaskCommentsResponseDTOList(),"list of comments", ResponseEnum.SUCCESS);
        given(taskCommentsService.getAllTaskComments(1L)).willReturn(response);

        mockMvc.perform(get("/api/v1/task/comments/get/{taskId}",1))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("list of comments"))
                .andExpect(jsonPath("$.response[0].comment").value("This is 1st Comment"));


    }
    @Test
    void createTaskCommentsTest() throws Exception {
        Long taskId = 1L;
        Long userId = 1L;
        String comment = "creating comment";
        TaskCommentDTO taskCommentDTO = new TaskCommentDTO(taskId,userId);
        taskCommentDTO.setComment(comment);

        ResponsePayload response = new ResponsePayload("Comment added successfully", ResponseEnum.SUCCESS, HttpStatus.OK);
        given(taskCommentsService.createTaskComments(taskCommentDTO)).willReturn(response);

        mockMvc.perform(post("/api/v1/task/comments/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(taskCommentDTO))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Comment added successfully"));

    }
    @Test
    void updateTaskCommentsTest() throws Exception {
        CommentDTO commentDTO = new CommentDTO();
        commentDTO.setComment("comment updated");
        ResponsePayload response = new ResponsePayload("Comment updated successfully",ResponseEnum.SUCCESS,HttpStatus.OK);
        given(taskCommentsService.updateTaskComments(1L,commentDTO)).willReturn(response);

        mockMvc.perform(put("/api/v1/task/comments/update/{commentId}",1)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(commentDTO))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Comment updated successfully"));



    }
    @Test
    void deleteTaskComments() throws Exception {

        ResponsePayload response = new ResponsePayload("Comment deleted successfully", ResponseEnum.SUCCESS,HttpStatus.OK);
        given(taskCommentsService.deleteTaskComments(1L)).willReturn(response);

        mockMvc.perform(delete("/api/v1/task/comments/delete/{commentId}",1))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Comment deleted successfully"));


    }


}

