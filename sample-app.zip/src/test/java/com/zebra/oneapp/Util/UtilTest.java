package com.zebra.oneapp.Util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.zebra.oneapp.dto.TaskCommentsResponseDTO;
import com.zebra.oneapp.dto.TaskDetailResponseDTO;
import com.zebra.oneapp.dto.TaskHistoryResponseDTO;
import com.zebra.oneapp.dto.UserResponseDTO;

public class UtilTest {
    public List<TaskCommentsResponseDTO> getTaskCommentsResponseDTOList(){
        List<TaskCommentsResponseDTO> taskCommentsResponseDTOList = new ArrayList<>();
        TaskCommentsResponseDTO taskCommentsResponseDTO = new TaskCommentsResponseDTO();
        taskCommentsResponseDTO.setId(1L);
        taskCommentsResponseDTO.setDate(LocalDateTime.now());
        taskCommentsResponseDTO.setComment("This is 1st Comment");
        taskCommentsResponseDTO.setUser(getUserResponseDTO());
        taskCommentsResponseDTOList.add(taskCommentsResponseDTO);
        return taskCommentsResponseDTOList;
    }
    public List<TaskHistoryResponseDTO> getTaskHistoryResponseDTOList(){
        List<TaskHistoryResponseDTO> taskHistoryResponseDTOList = new ArrayList<>();
        TaskHistoryResponseDTO taskHistoryResponseDTO = new TaskHistoryResponseDTO();
        taskHistoryResponseDTO.setId(1L);
        taskHistoryResponseDTO.setDate(LocalDate.now().toString());
        taskHistoryResponseDTO.setStatus("Assigned");
        taskHistoryResponseDTO.setUserName(getUserResponseDTO().getFirstName()+" "+getUserResponseDTO().getLastName());
        taskHistoryResponseDTOList.add(taskHistoryResponseDTO);
        return taskHistoryResponseDTOList;
    }
    public UserResponseDTO getUserResponseDTO(){
        UserResponseDTO userResponseDTO = new UserResponseDTO();
        userResponseDTO.setId(1L);
        userResponseDTO.setEmail("s@gmail.com");
        userResponseDTO.setFirstName("Shruti");
        userResponseDTO.setLastName("Sharma");
        return userResponseDTO;
    }
    public TaskDetailResponseDTO getTaskResponseDTO(){
        TaskDetailResponseDTO responseDTO = new TaskDetailResponseDTO();
        responseDTO.setId(1L);
        responseDTO.setStatus("Assigned");
        responseDTO.setDescription("This is for test");
        responseDTO.setPriority(1);
        responseDTO.setAssignedUser(getUserResponseDTO());
        responseDTO.setComments(getTaskCommentsResponseDTOList());
        //responseDTO.setTaskHistories(getTaskHistoryResponseDTOList());
        return responseDTO;
    }

}
